import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { AuthModal } from './components/AuthModal';
import { DashboardView } from './components/DashboardView';
import { PlansView } from './components/PlansView';
import { WatchVideosView } from './components/WatchVideosView';
import { DepositView } from './components/DepositView';
import { WithdrawView } from './components/WithdrawView';
import { TransactionHistoryView } from './components/TransactionHistoryView';
import { ReferralView } from './components/ReferralView';
import { ProfileView } from './components/ProfileView';
import { LeaderboardView } from './components/LeaderboardView';
import { SupportView } from './components/SupportView';
import { AdminPanelView } from './components/AdminPanelView';
import { DownloadAppModal } from './components/DownloadAppModal';
import { api, getStoredToken } from './services/api';
import {
  User,
  Plan,
  VideoTask,
  Deposit,
  Withdrawal,
  Transaction,
  SupportTicket,
  PlatformSettings,
  Announcement,
} from './types';
import { Coins, Phone, MessageCircle, ShieldCheck, Heart, Download, Smartphone } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authInitialTab, setAuthInitialTab] = useState<'login' | 'register'>('login');
  const [downloadAppModalOpen, setDownloadAppModalOpen] = useState(false);
  const [urlReferralCode, setUrlReferralCode] = useState<string>('');

  // App Data
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [selectedPlanId, setSelectedPlanId] = useState<number>(1);
  const [activePlan, setActivePlan] = useState<Plan | null>(null);
  const [isPlanActive, setIsPlanActive] = useState<boolean>(false);
  const [remainingDays, setRemainingDays] = useState<number>(0);

  // Videos
  const [videos, setVideos] = useState<VideoTask[]>([]);
  const [completedTodayCount, setCompletedTodayCount] = useState<number>(0);
  const [maxDailyVideos, setMaxDailyVideos] = useState<number>(2);
  const [requiresPlan, setRequiresPlan] = useState<boolean>(true);

  // Lists
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>([]);
  const [leaderboard, setLeaderboard] = useState<
    { name: string; maskedMobile: string; totalRewards: number; plan: string }[]
  >([]);

  // Referral
  const [referralStats, setReferralStats] = useState<{
    referralCode: string;
    totalInvited: number;
    referredUsers: { fullName: string; mobile: string; createdAt: string; activePlan: string }[];
    totalReferralRewards: number;
    commissionRate: number;
  }>({
    referralCode: '',
    totalInvited: 0,
    referredUsers: [],
    totalReferralRewards: 0,
    commissionRate: 5,
  });

  const [loading, setLoading] = useState(true);

  // Check URL referral code
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const ref = params.get('ref');
      if (ref) {
        setUrlReferralCode(ref.toUpperCase());
        if (!getStoredToken()) {
          setAuthInitialTab('register');
          setAuthModalOpen(true);
        }
      }
    }
  }, []);

  // Initial Data Fetch
  const loadInitialData = async () => {
    setLoading(true);
    try {
      const [settingsRes, plansRes, leaderRes] = await Promise.all([
        api.getSettings(),
        api.getPlans(),
        api.getLeaderboard(),
      ]);
      setSettings(settingsRes.settings);
      setAnnouncements(settingsRes.announcements);
      setPlans(plansRes.plans);
      setLeaderboard(leaderRes.leaderboard);

      const token = getStoredToken();
      if (token) {
        await refreshUserData();
      }
    } catch (err) {
      console.error('Error loading initial data:', err);
    } finally {
      setLoading(false);
    }
  };

  const refreshUserData = async () => {
    try {
      const [dashRes, vidsRes, depRes, wthRes, trxRes, refRes, suppRes, leaderRes] =
        await Promise.all([
          api.getDashboard(),
          api.getVideos(),
          api.getDeposits(),
          api.getWithdrawals(),
          api.getTransactions(),
          api.getReferrals(),
          api.getSupportTickets(),
          api.getLeaderboard(),
        ]);

      setUser(dashRes.user);
      setActivePlan(dashRes.activePlan);
      setIsPlanActive(dashRes.isPlanActive);
      setRemainingDays(dashRes.remainingDays);
      setCompletedTodayCount(dashRes.completedToday);
      setMaxDailyVideos(dashRes.maxDailyVideos);

      setVideos(vidsRes.videos);
      setRequiresPlan(vidsRes.requiresPlan);

      setDeposits(depRes.deposits);
      setWithdrawals(wthRes.withdrawals);
      setTransactions(trxRes.transactions);
      setReferralStats(refRes);
      setSupportTickets(suppRes.tickets);
      setLeaderboard(leaderRes.leaderboard);
    } catch (err) {
      console.error('Failed to refresh user data:', err);
      // If auth token was invalid, clear user
      setUser(null);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  const handleLogout = () => {
    api.logout();
    setUser(null);
    setActivePlan(null);
    setIsPlanActive(false);
    setActiveTab('dashboard');
  };

  const handleLoginSuccess = (loggedInUser: User) => {
    setUser(loggedInUser);
    refreshUserData();
    setActiveTab('dashboard');
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col font-sans selection:bg-amber-400 selection:text-neutral-950">
      {/* Top Navigation */}
      <Navbar
        user={user}
        settings={settings}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLogout={handleLogout}
        onOpenAuth={() => {
          setAuthInitialTab('login');
          setAuthModalOpen(true);
        }}
        onOpenDownloadApp={() => setDownloadAppModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-20 md:pb-12">
        {loading ? (
          <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-3">
            <div className="w-10 h-10 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
            <p className="text-xs text-neutral-400 font-mono tracking-wider uppercase">
              Loading ProfitNest Platform...
            </p>
          </div>
        ) : !user && activeTab !== 'plans' && activeTab !== 'leaderboard' && activeTab !== 'support' ? (
          // Landing View for non-logged in visitors
          <div className="max-w-4xl mx-auto py-12 space-y-12 text-center">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
                <Coins className="w-4 h-4" />
                <span>Watch • Earn • Rewards</span>
              </div>
              <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-tight">
                Welcome to <span className="bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 bg-clip-text text-transparent">ProfitNest</span>
              </h1>
              <p className="text-sm sm:text-base text-neutral-300 max-w-2xl mx-auto leading-relaxed">
                Simple, transparent earning and video rewards platform. Choose from 12 flexible 30-day plans, complete 2 daily verified advertising tasks, and receive payouts via Easypaisa, JazzCash, or Bank Transfer.
              </p>

              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => {
                    setAuthInitialTab('register');
                    setAuthModalOpen(true);
                  }}
                  className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-neutral-950 font-black text-sm shadow-xl shadow-amber-500/20 transition-all"
                >
                  Create Account Now
                </button>
                <button
                  onClick={() => {
                    setAuthInitialTab('login');
                    setAuthModalOpen(true);
                  }}
                  className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-sm border border-neutral-700 transition-all"
                >
                  Sign In
                </button>
                <button
                  onClick={() => setDownloadAppModalOpen(true)}
                  className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-amber-300 hover:text-white font-bold text-sm border border-amber-500/40 transition-all flex items-center justify-center gap-2 shadow-sm"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  Download App
                </button>
                <button
                  onClick={() => setActiveTab('plans')}
                  className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-neutral-950 text-neutral-300 hover:text-white text-sm font-semibold border border-neutral-800 transition-all"
                >
                  Plans →
                </button>
              </div>
            </div>

            {/* Feature Highlights Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-left">
              <div className="p-6 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-2">
                <div className="p-3 rounded-xl bg-amber-400/10 text-amber-400 w-fit">
                  <Coins className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-white text-base">12 Transparent Plans</h3>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Start from Rs. 290 up to Rs. 593,920. Fixed 30-day cycle with daily video task rewards and zero hidden charges.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-2">
                <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 w-fit">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-white text-base">Verified Partner Media</h3>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Genuine rewards credited directly to your balance from authentic advertising and media tasks upon completed viewing.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-2">
                <div className="p-3 rounded-xl bg-blue-500/10 text-blue-400 w-fit">
                  <Heart className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-white text-base">Direct Local Payouts</h3>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Withdraw to your Easypaisa, JazzCash, or bank account. All requests are personally verified and paid by Shabahat Ali Kazmi.
                </p>
              </div>
            </div>

            {/* Contact Strip */}
            <div className="p-6 rounded-2xl bg-neutral-950 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
              <div className="text-left">
                <span className="text-[10px] text-amber-400 uppercase font-bold tracking-wider block">
                  Official Platform Administration
                </span>
                <span className="text-sm font-bold text-white">Shabahat Ali Kazmi</span>
                <span className="text-neutral-400 block">Owner Contact: 0331 5014004 • Admin: 0343 9054908</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('support')}
                  className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-semibold border border-neutral-700"
                >
                  Contact Support
                </button>
              </div>
            </div>
          </div>
        ) : (
          // Authenticated Views
          <>
            {activeTab === 'dashboard' && user && (
              <DashboardView
                user={user}
                activePlan={activePlan}
                isPlanActive={isPlanActive}
                remainingDays={remainingDays}
                completedToday={completedTodayCount}
                maxDailyVideos={maxDailyVideos}
                recentTransactions={transactions}
                announcements={announcements}
                setActiveTab={setActiveTab}
                onRefresh={refreshUserData}
                onOpenDownloadApp={() => setDownloadAppModalOpen(true)}
              />
            )}

            {activeTab === 'plans' && (
              <PlansView
                plans={plans}
                user={user}
                onSelectPlan={(planId) => setSelectedPlanId(planId)}
                setActiveTab={setActiveTab}
              />
            )}

            {activeTab === 'videos' && user && (
              <WatchVideosView
                user={user}
                videos={videos}
                completedTodayCount={completedTodayCount}
                maxDailyVideos={maxDailyVideos}
                requiresPlan={requiresPlan}
                activePlan={activePlan}
                onRewardClaimed={refreshUserData}
                setActiveTab={setActiveTab}
              />
            )}

            {activeTab === 'deposit' && user && (
              <DepositView
                user={user}
                plans={plans}
                selectedPlanId={selectedPlanId}
                setSelectedPlanId={setSelectedPlanId}
                paymentMethods={settings?.paymentMethods || []}
                deposits={deposits}
                onDepositSubmitted={refreshUserData}
              />
            )}

            {activeTab === 'withdraw' && user && (
              <WithdrawView
                user={user}
                paymentMethods={settings?.paymentMethods || []}
                withdrawals={withdrawals}
                availableBalance={user.balance}
                onWithdrawalSubmitted={refreshUserData}
                setActiveTab={setActiveTab}
              />
            )}

            {activeTab === 'transactions' && user && (
              <TransactionHistoryView transactions={transactions} />
            )}

            {activeTab === 'referral' && user && (
              <ReferralView
                user={user}
                referralCode={referralStats.referralCode}
                totalInvited={referralStats.totalInvited}
                referredUsers={referralStats.referredUsers}
                totalReferralRewards={referralStats.totalReferralRewards}
                commissionRate={referralStats.commissionRate}
              />
            )}

            {activeTab === 'profile' && user && (
              <ProfileView
                user={user}
                activePlan={activePlan}
                isPlanActive={isPlanActive}
                remainingDays={remainingDays}
                onLogout={handleLogout}
                setActiveTab={setActiveTab}
                onRefresh={refreshUserData}
              />
            )}

            {activeTab === 'leaderboard' && (
              <LeaderboardView leaderboard={leaderboard} />
            )}

            {activeTab === 'support' && (
              <SupportView
                user={user}
                settings={settings}
                tickets={supportTickets}
                onTicketSubmitted={refreshUserData}
              />
            )}

            {activeTab === 'admin' && user?.role === 'admin' && (
              <AdminPanelView adminUser={user} onRefreshData={refreshUserData} />
            )}
          </>
        )}
      </main>

      {/* Mobile Bottom Navigation (Strictly 5 Options per Requirement 13) */}
      <MobileBottomNav activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Global Footer */}
      <footer className="border-t border-neutral-900 bg-neutral-950 text-neutral-400 py-8 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="p-1 rounded bg-amber-400/20 text-amber-400">
                <Coins className="w-4 h-4" />
              </div>
              <span className="font-extrabold text-white text-sm">ProfitNest</span>
              <span className="text-neutral-500">•</span>
              <span>Watch • Earn • Rewards</span>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-[11px] text-neutral-400">
              <span>Owner: Shabahat Ali Kazmi (0331 5014004)</span>
              <span>•</span>
              <span>Admin: Shabahat Ali Kazmi (0343 9054908)</span>
            </div>
          </div>

          <div className="pt-4 border-t border-neutral-900/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] text-neutral-500">
            <p>© {new Date().getFullYear()} ProfitNest. All rights reserved. Clean, verified earning platform.</p>
            <p>Non-guaranteed rewards. All earnings subject to completed advertising tasks & manual admin verification.</p>
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={handleLoginSuccess}
        initialTab={authInitialTab}
        defaultReferralCode={urlReferralCode}
      />

      {/* Download App Modal */}
      <DownloadAppModal
        isOpen={downloadAppModalOpen}
        onClose={() => setDownloadAppModalOpen(false)}
      />
    </div>
  );
}
