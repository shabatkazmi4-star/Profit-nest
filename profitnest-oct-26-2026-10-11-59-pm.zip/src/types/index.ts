export interface User {
  id: string;
  fullName: string;
  mobile: string;
  role: 'user' | 'admin';
  referralCode: string;
  referredBy?: string;
  balance: number;
  totalVerifiedRewards: number;
  activePlanId: number | null;
  planActivationDate: string | null;
  planExpiryDate: string | null;
  createdAt: string;
}

export interface Plan {
  id: number;
  name: string;
  price: number;
  validityDays: number;
  dailyVideos: number;
  rewardPerVideo: number;
  dailyEarning: number;
}

export interface VideoTask {
  id: string;
  title: string;
  durationSeconds: number;
  videoUrl: string;
  thumbnail: string;
  category: string;
  sponsor: string;
  rewardAmount: number;
  isCompleted: boolean;
  canWatch: boolean;
}

export interface Deposit {
  id: string;
  userId: string;
  planId: number;
  amount: number;
  paymentMethod: string;
  senderNumber: string;
  transactionId: string;
  notes?: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  adminNote?: string;
  createdAt: string;
  updatedAt: string;
  userName?: string;
  userMobile?: string;
  planName?: string;
}

export interface Withdrawal {
  id: string;
  userId: string;
  amount: number;
  accountHolder: string;
  paymentMethod: string;
  accountNumber: string;
  status: 'Pending' | 'Processing' | 'Paid' | 'Rejected';
  adminReference?: string;
  createdAt: string;
  updatedAt: string;
  userName?: string;
  userMobile?: string;
}

export interface Transaction {
  id: string;
  userId: string;
  type: 'Deposit' | 'Withdrawal' | 'Video Reward' | 'Referral Reward';
  amount: number;
  status: string;
  description: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  mobile: string;
  subject: string;
  message: string;
  category: string;
  status: 'Open' | 'In Progress' | 'Resolved';
  adminReply?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentMethodConfig {
  id: string;
  name: string;
  accountTitle: string;
  accountNumber: string;
  bankName?: string;
  instructions: string;
  enabled: boolean;
}

export interface PlatformSettings {
  websiteName: string;
  tagline: string;
  ownerName: string;
  ownerContact: string;
  adminName: string;
  adminContact: string;
  referralCommissionRate: number;
  paymentMethods: PaymentMethodConfig[];
}

export interface Announcement {
  id: string;
  title: string;
  message: string;
  active: boolean;
  createdAt: string;
}

export interface AdminLog {
  id: string;
  action: string;
  details: string;
  adminMobile: string;
  createdAt: string;
}
