import React, { useState } from 'react';
import {
  Coins,
  ShieldCheck,
  LayoutDashboard,
  PlaySquare,
  Package,
  ArrowDownCircle,
  ArrowUpCircle,
  History,
  Users,
  User as UserIcon,
  HelpCircle,
  LogOut,
  Menu,
  X,
  Trophy,
  Download,
} from 'lucide-react';
import { User, PlatformSettings } from '../types';

interface NavbarProps {
  user: User | null;
  settings: PlatformSettings | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
  onOpenAuth: () => void;
  onOpenDownloadApp: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  settings,
  activeTab,
  setActiveTab,
  onLogout,
  onOpenAuth,
  onOpenDownloadApp,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'plans', label: 'Plans', icon: Package },
    { id: 'videos', label: 'Watch Videos', icon: PlaySquare },
    { id: 'deposit', label: 'Deposit', icon: ArrowDownCircle },
    { id: 'withdraw', label: 'Withdraw', icon: ArrowUpCircle },
    { id: 'transactions', label: 'Transactions', icon: History },
    { id: 'referral', label: 'Referral', icon: Users },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
    { id: 'support', label: 'Support', icon: HelpCircle },
    { id: 'profile', label: 'Profile', icon: UserIcon },
  ];

  const handleNavClick = (tabId: string) => {
    setActiveTab(tabId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-neutral-950/95 backdrop-blur-md border-b border-amber-500/20 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Tagline */}
          <div
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 p-[1px] shadow-lg shadow-amber-500/20">
              <div className="w-full h-full bg-neutral-950 rounded-xl flex items-center justify-center">
                <Coins className="w-5 h-5 text-amber-400 group-hover:rotate-12 transition-transform duration-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight bg-gradient-to-r from-white via-neutral-100 to-amber-300 bg-clip-text text-transparent">
                  {settings?.websiteName || 'ProfitNest'}
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  Official
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 font-medium tracking-wide">
                {settings?.tagline || 'Watch • Earn • Rewards'}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {user ? (
              <>
                {navLinks.slice(0, 7).map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleNavClick(item.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        isActive
                          ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30 font-semibold'
                          : 'text-neutral-300 hover:text-white hover:bg-neutral-800/60'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {item.label}
                    </button>
                  );
                })}

                {user.role === 'admin' && (
                  <button
                    onClick={() => handleNavClick('admin')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      activeTab === 'admin'
                        ? 'bg-amber-400 text-neutral-950 shadow-md shadow-amber-500/30'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                    }`}
                  >
                    <ShieldCheck className="w-4 h-4" />
                    Admin Panel
                  </button>
                )}
              </>
            ) : null}
          </nav>

          {/* Right Section: Balance & User Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Download App Action Button */}
            <button
              onClick={onOpenDownloadApp}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-400/15 via-yellow-500/20 to-amber-600/15 border border-amber-500/40 text-amber-300 hover:text-white hover:bg-amber-500/25 transition-all text-xs font-bold shadow-sm"
              title="Download ProfitNest Mobile App"
            >
              <Download className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
              <span className="hidden sm:inline">Download App</span>
              <span className="sm:hidden">App</span>
            </button>

            {user ? (
              <>
                {/* Balance Badge */}
                <div
                  onClick={() => setActiveTab('withdraw')}
                  className="cursor-pointer flex items-center gap-2 px-3 py-1.5 rounded-lg bg-neutral-900 border border-amber-500/30 hover:border-amber-400 transition-colors shadow-sm"
                  title="Click to withdraw funds"
                >
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <div className="text-right">
                    <span className="text-[10px] text-neutral-400 uppercase tracking-wider block leading-none">
                      Balance
                    </span>
                    <span className="text-sm font-bold text-amber-400">
                      Rs. {user.balance.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Profile / Logout */}
                <div className="hidden sm:flex items-center gap-2">
                  <button
                    onClick={() => setActiveTab('profile')}
                    className="p-2 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white hover:border-neutral-700 transition-all"
                    title="User Profile"
                  >
                    <UserIcon className="w-4 h-4" />
                  </button>
                  <button
                    onClick={onLogout}
                    className="p-2 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-red-400 hover:border-red-900/50 transition-all"
                    title="Log out"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-4 py-2 rounded-lg bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 text-xs sm:text-sm font-bold shadow-md shadow-amber-500/20 hover:from-amber-300 hover:to-yellow-400 transition-all"
              >
                Login / Register
              </button>
            )}

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-neutral-950 border-b border-neutral-800 px-4 pt-3 pb-5 space-y-2">
          {user ? (
            <>
              <div className="p-3 mb-2 rounded-xl bg-neutral-900/80 border border-amber-500/20 flex items-center justify-between">
                <div>
                  <div className="text-xs text-neutral-400 font-medium">Logged in as</div>
                  <div className="text-sm font-bold text-white">{user.fullName}</div>
                  <div className="text-[11px] text-amber-400/90 font-mono">{user.mobile}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-neutral-400 uppercase">Available</div>
                  <div className="text-base font-bold text-amber-400">Rs. {user.balance.toLocaleString()}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {navLinks.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleNavClick(item.id)}
                      className={`flex items-center gap-2 p-2.5 rounded-lg text-xs font-medium text-left transition-all ${
                        isActive
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-neutral-900/50 text-neutral-300 hover:bg-neutral-800'
                      }`}
                    >
                      <Icon className="w-4 h-4 text-amber-400/80" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>

              {user.role === 'admin' && (
                <button
                  onClick={() => handleNavClick('admin')}
                  className="w-full flex items-center justify-center gap-2 p-2.5 mt-2 rounded-lg bg-amber-400 text-neutral-950 font-bold text-xs"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Admin Panel (Shabahat Ali Kazmi)
                </button>
              )}

              <button
                onClick={() => {
                  onOpenDownloadApp();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center gap-2 p-2.5 mt-2 rounded-lg bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-bold text-xs shadow-md shadow-amber-500/20"
              >
                <Download className="w-4 h-4" />
                Download ProfitNest App (APK)
              </button>

              <button
                onClick={() => {
                  onLogout();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center gap-2 p-2.5 mt-2 rounded-lg bg-neutral-900 text-red-400 border border-red-900/30 hover:bg-red-950/30 text-xs font-semibold"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </>
          ) : (
            <div className="py-2 text-center">
              <button
                onClick={() => {
                  onOpenAuth();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 rounded-lg bg-amber-400 text-neutral-950 font-bold text-sm"
              >
                Log In or Create Account
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
