import React, { useState } from 'react';
import {
  Users,
  Copy,
  Check,
  Share2,
  Coins,
  ShieldCheck,
  Award,
  ArrowRight,
  MessageCircle,
} from 'lucide-react';
import { User } from '../types';

interface ReferralViewProps {
  user: User;
  referralCode: string;
  totalInvited: number;
  referredUsers: { fullName: string; mobile: string; createdAt: string; activePlan: string }[];
  totalReferralRewards: number;
  commissionRate: number;
}

export const ReferralView: React.FC<ReferralViewProps> = ({
  user,
  referralCode,
  totalInvited,
  referredUsers,
  totalReferralRewards,
  commissionRate,
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Dynamic referral link based on window location
  const appOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://profitnest.app';
  const referralLink = `${appOrigin}/?ref=${referralCode}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleWhatsAppShare = () => {
    const text = encodeURIComponent(
      `Join ProfitNest - Watch, Earn & Rewards platform! Use my official invite code *${referralCode}* to register and start earning verified rewards:\n${referralLink}`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-12">
      {/* Header */}
      <div className="text-center space-y-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-bold uppercase tracking-wider">
          <Users className="w-3.5 h-3.5" />
          <span>Affiliate & Referral Network</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Invite Friends & Earn <span className="text-amber-400">{commissionRate}% Verified Bonus</span>
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400">
          Share your exclusive referral code with partners and friends. Earn an instant {commissionRate}% commission on every confirmed 30-day plan activation.
        </p>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-md">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1">
            Total Invited Members
          </span>
          <div className="text-3xl font-black text-white">
            {totalInvited} <span className="text-xs font-normal text-neutral-500">Users</span>
          </div>
          <p className="text-[11px] text-neutral-500 mt-1">Real registered partners</p>
        </div>

        <div className="rounded-2xl bg-neutral-900 border border-amber-500/30 p-6 shadow-md">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1">
            Verified Referral Rewards
          </span>
          <div className="text-3xl font-black text-amber-400">
            Rs. {totalReferralRewards.toLocaleString()}
          </div>
          <p className="text-[11px] text-neutral-500 mt-1">Credited directly to available balance</p>
        </div>

        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-md sm:col-span-2 lg:col-span-1">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1">
            Commission Rate
          </span>
          <div className="text-3xl font-black text-emerald-400">
            {commissionRate}% <span className="text-xs font-normal text-neutral-500">on activation</span>
          </div>
          <p className="text-[11px] text-neutral-500 mt-1">Directly upon deposit confirmation</p>
        </div>
      </div>

      {/* Sharing Link & Code Section */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 sm:p-8 shadow-xl space-y-6">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Share2 className="w-5 h-5 text-amber-400" />
          Your Exclusive Referral Credentials
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Referral Code Box */}
          <div className="p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block">
              My Referral Code
            </span>
            <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-900 border border-amber-500/30">
              <span className="text-xl font-mono font-black text-amber-400 tracking-wider">
                {referralCode}
              </span>
              <button
                type="button"
                onClick={handleCopyCode}
                className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-bold text-white transition-colors flex items-center gap-1.5"
              >
                {copiedCode ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-[11px] text-neutral-500">
              New members can paste this code during registration.
            </p>
          </div>

          {/* Referral Link Box */}
          <div className="p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block">
              My Referral Link
            </span>
            <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-900 border border-neutral-800">
              <span className="text-xs font-mono text-neutral-300 truncate max-w-[200px] sm:max-w-xs">
                {referralLink}
              </span>
              <button
                type="button"
                onClick={handleCopyLink}
                className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-bold text-white transition-colors flex items-center gap-1.5 shrink-0"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Link</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-[11px] text-neutral-500">
              Auto-fills your referral code on the registration page.
            </p>
          </div>
        </div>

        {/* Action Buttons: WhatsApp Share */}
        <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
          <button
            onClick={handleWhatsAppShare}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            Share via WhatsApp
          </button>
          <button
            onClick={handleCopyLink}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs sm:text-sm border border-neutral-700 transition-all flex items-center justify-center gap-2"
          >
            <Copy className="w-4 h-4" />
            Copy Shareable Link
          </button>
        </div>
      </div>

      {/* Transparent Referral Policy */}
      <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-400 text-xs flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <div className="font-bold text-white mb-1">Published Transparent Referral Rules</div>
          <p>
            ProfitNest strictly prohibits fake accounts, self-referrals, and artificial commission loops. A referral reward is generated only after a real user completes payment for their 30-day plan and it is verified by Administrator Shabahat Ali Kazmi.
          </p>
        </div>
      </div>

      {/* Invited Users List */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Users className="w-5 h-5 text-amber-400" />
          Invited Members List ({referredUsers.length})
        </h3>

        {referredUsers.length === 0 ? (
          <div className="py-8 text-center text-xs text-neutral-500">
            No invited members yet. Share your code or WhatsApp link to invite friends.
          </div>
        ) : (
          <div className="divide-y divide-neutral-800">
            {referredUsers.map((member, i) => (
              <div key={i} className="py-3 flex items-center justify-between text-xs sm:text-sm">
                <div>
                  <div className="font-bold text-white">{member.fullName}</div>
                  <div className="text-[11px] text-neutral-400 font-mono">
                    Mobile: {member.mobile} • Joined: {new Date(member.createdAt).toLocaleDateString()}
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[11px] font-semibold">
                    {member.activePlan}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
