import React, { useState, useEffect } from 'react';
import {
  Download,
  Smartphone,
  CheckCircle2,
  Share,
  X,
  ShieldCheck,
  Zap,
  ArrowRight,
  ExternalLink,
  Sparkles,
  Info,
} from 'lucide-react';

interface DownloadAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadAppModal: React.FC<DownloadAppModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [activeTab, setActiveTab] = useState<'android' | 'ios'>('android');
  const [downloadStarted, setDownloadStarted] = useState(false);

  useEffect(() => {
    // Detect if already installed in standalone mode
    if (typeof window !== 'undefined') {
      const isStandalone =
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true;
      setIsInstalled(isStandalone);

      const handlePrompt = (e: any) => {
        e.preventDefault();
        setDeferredPrompt(e);
      };

      const handleInstalled = () => {
        setIsInstalled(true);
        setDeferredPrompt(null);
      };

      window.addEventListener('beforeinstallprompt', handlePrompt);
      window.addEventListener('appinstalled', handleInstalled);

      return () => {
        window.removeEventListener('beforeinstallprompt', handlePrompt);
        window.removeEventListener('appinstalled', handleInstalled);
      };
    }
  }, []);

  if (!isOpen) return null;

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      // Trigger APK direct download fallback
      handleDownloadAPK();
    }
  };

  const handleDownloadAPK = () => {
    setDownloadStarted(true);
    const link = document.createElement('a');
    link.href = '/api/download/apk';
    link.download = 'ProfitNest-v1.0.4.apk';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => setDownloadStarted(false), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-neutral-950 border border-amber-500/40 rounded-2xl p-6 sm:p-7 shadow-2xl text-white my-8 space-y-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-600 p-[1px] shadow-lg shadow-amber-500/20 shrink-0">
            <div className="w-full h-full bg-neutral-950 rounded-2xl flex items-center justify-center">
              <Smartphone className="w-7 h-7 text-amber-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-white">Download ProfitNest App</h2>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-400 text-neutral-950">
                v1.0.4
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">
              Watch videos smoothly, get instant payout alerts, and earn on the go.
            </p>
          </div>
        </div>

        {/* Platform Selector Tabs */}
        <div className="grid grid-cols-2 p-1 bg-neutral-900 border border-neutral-800 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveTab('android')}
            className={`py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'android'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Android (APK & Install)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ios')}
            className={`py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'ios'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            iPhone / iPad (iOS)
          </button>
        </div>

        {/* Tab 1: Android Flow */}
        {activeTab === 'android' && (
          <div className="space-y-4">
            {/* Quick Specs Pill */}
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase block">Size</span>
                <span className="font-bold text-white">8.4 MB</span>
              </div>
              <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase block">Compatibility</span>
                <span className="font-bold text-amber-400">Android 6.0+</span>
              </div>
              <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase block">Security</span>
                <span className="font-bold text-emerald-400">Verified Clean</span>
              </div>
            </div>

            {/* Download Status Toast */}
            {downloadStarted && (
              <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>Your ProfitNest APK download has started! Open it on your phone to install.</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-2.5 pt-1">
              <button
                onClick={handleDownloadAPK}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-neutral-950 font-black text-sm shadow-xl shadow-amber-500/20 transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-5 h-5" />
                Download Android APK (8.4 MB)
              </button>

              {deferredPrompt && (
                <button
                  onClick={handleInstallPWA}
                  className="w-full py-3 px-4 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs border border-neutral-700 transition-all flex items-center justify-center gap-2"
                >
                  <Zap className="w-4 h-4 text-amber-400" />
                  Install Web App on Home Screen (Instant)
                </button>
              )}
            </div>

            {/* Installation Instructions */}
            <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800 text-xs text-neutral-300 space-y-1.5">
              <div className="font-bold text-amber-400 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5" />
                How to install on Android:
              </div>
              <ol className="list-decimal list-inside text-[11px] text-neutral-400 space-y-1">
                <li>Tap <strong className="text-neutral-200">Download Android APK</strong> above.</li>
                <li>When prompted by Chrome/browser, tap <strong className="text-neutral-200">Download anyway</strong>.</li>
                <li>Open the downloaded <strong className="text-neutral-200">ProfitNest-v1.0.4.apk</strong> file and tap <strong className="text-neutral-200">Install</strong>.</li>
              </ol>
            </div>
          </div>
        )}

        {/* Tab 2: iOS Guide */}
        {activeTab === 'ios' && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 text-xs space-y-3">
              <div className="font-bold text-amber-400 text-sm">
                Install on iPhone or iPad (No App Store required):
              </div>
              <ol className="space-y-2.5 text-neutral-300 leading-relaxed list-decimal list-inside">
                <li>
                  Open <span className="font-semibold text-white">ProfitNest</span> in <span className="font-semibold text-white">Safari</span> browser.
                </li>
                <li>
                  Tap the <span className="font-semibold text-amber-400">Share button</span> (the square icon with the upward arrow at the bottom of Safari).
                </li>
                <li>
                  Scroll down the options and select <span className="font-semibold text-amber-400">"Add to Home Screen"</span>.
                </li>
                <li>
                  Tap <span className="font-semibold text-white">"Add"</span> in the top right corner.
                </li>
              </ol>
              <div className="pt-2 text-[11px] text-neutral-400">
                ProfitNest will appear on your iPhone home screen just like a regular native iOS app with full screen performance!
              </div>
            </div>

            <button
              onClick={() => {
                window.location.href = '/';
                onClose();
              }}
              className="w-full py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-amber-400 font-bold text-xs border border-amber-500/30 transition-all flex items-center justify-center gap-2"
            >
              Open Safari Home Screen Experience
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Security & Official Administration Disclaimer */}
        <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Official ProfitNest Application • Verified by Shabahat Ali Kazmi</span>
          </div>
        </div>
      </div>
    </div>
  );
};
