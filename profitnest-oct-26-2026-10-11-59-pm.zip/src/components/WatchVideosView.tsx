import React, { useState, useRef, useEffect } from 'react';
import {
  PlaySquare,
  CheckCircle2,
  Lock,
  Play,
  AlertCircle,
  Clock,
  Coins,
  ShieldCheck,
  X,
  Sparkles,
} from 'lucide-react';
import { VideoTask, User } from '../types';
import { api } from '../services/api';

interface WatchVideosViewProps {
  user: User;
  videos: VideoTask[];
  completedTodayCount: number;
  maxDailyVideos: number;
  requiresPlan: boolean;
  activePlan: { name: string; price: number; rewardPerVideo: number } | null;
  onRewardClaimed: () => void;
  setActiveTab: (tab: string) => void;
}

export const WatchVideosView: React.FC<WatchVideosViewProps> = ({
  user,
  videos,
  completedTodayCount,
  maxDailyVideos,
  requiresPlan,
  activePlan,
  onRewardClaimed,
  setActiveTab,
}) => {
  const [activeVideo, setActiveVideo] = useState<VideoTask | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [watchSeconds, setWatchSeconds] = useState(0);
  const [canClaim, setCanClaim] = useState(false);
  const [claiming, setClaiming] = useState(false);
  const [claimSuccess, setClaimSuccess] = useState<string | null>(null);
  const [claimError, setClaimError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Watch countdown logic
  useEffect(() => {
    if (isPlaying && activeVideo && !canClaim) {
      timerRef.current = setInterval(() => {
        setWatchSeconds((prev) => {
          const next = prev + 1;
          if (next >= activeVideo.durationSeconds) {
            setCanClaim(true);
            setIsPlaying(false);
            if (timerRef.current) clearInterval(timerRef.current);
            return activeVideo.durationSeconds;
          }
          return next;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, activeVideo, canClaim]);

  const startWatching = (video: VideoTask) => {
    setClaimSuccess(null);
    setClaimError(null);
    setActiveVideo(video);
    setWatchSeconds(0);
    setCanClaim(false);
    setIsPlaying(true);
  };

  const closeWatchModal = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setActiveVideo(null);
    setIsPlaying(false);
    setWatchSeconds(0);
    setCanClaim(false);
  };

  const handleClaimReward = async () => {
    if (!activeVideo) return;
    setClaiming(true);
    setClaimError(null);
    try {
      const res = await api.claimVideoReward({
        videoId: activeVideo.id,
        watchDurationSeconds: watchSeconds,
      });
      setClaimSuccess(res.message);
      onRewardClaimed();
      setTimeout(() => {
        closeWatchModal();
      }, 2000);
    } catch (err: any) {
      setClaimError(err.message || 'Reward claim failed.');
    } finally {
      setClaiming(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="text-center space-y-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <PlaySquare className="w-3.5 h-3.5" />
          <span>Daily Video Rewards</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Watch & Earn <span className="text-amber-400">Verified Rewards</span>
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400">
          Engage with eligible advertising partner media. Each verified video watch credits your account immediately upon completion.
        </p>
      </div>

      {/* Progress & Plan Status Bar */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-md flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-1 w-full md:w-auto">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Active Tier:
            </span>
            <span className="text-sm font-bold text-amber-400">
              {activePlan ? `${activePlan.name} (Rs. ${activePlan.rewardPerVideo}/video)` : 'No Active Plan'}
            </span>
          </div>
          <p className="text-xs text-neutral-400">
            {activePlan
              ? 'You are eligible to claim verified rewards for up to 2 tasks per day.'
              : 'Activate any 30-day plan to unlock daily video rewards.'}
          </p>
        </div>

        <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end">
          <div className="text-right">
            <span className="text-[11px] text-neutral-400 uppercase tracking-wider block">
              Daily Progress
            </span>
            <span className="text-xl font-black text-amber-400">
              {completedTodayCount} / {maxDailyVideos} Completed
            </span>
          </div>

          <div className="w-32 bg-neutral-950 rounded-full h-3 p-0.5 border border-neutral-800">
            <div
              className="bg-gradient-to-r from-amber-400 to-yellow-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${(completedTodayCount / maxDailyVideos) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Warning if no plan */}
      {requiresPlan && (
        <div className="p-4 rounded-xl bg-neutral-900/90 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-300">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-400/20 text-amber-400 shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-white text-sm">30-Day Plan Required</div>
              <p className="text-neutral-400">
                You must have an active 30-day plan to receive video task rewards. Choose from 12 affordable plans starting at Rs. 290.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('plans')}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-bold text-xs shrink-0 shadow-md shadow-amber-500/20 hover:from-amber-300 hover:to-yellow-400"
          >
            Select a Plan
          </button>
        </div>
      )}

      {/* Video Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {videos.map((vid, idx) => {
          return (
            <div
              key={vid.id}
              className={`rounded-2xl bg-neutral-900 border overflow-hidden flex flex-col justify-between shadow-lg transition-all ${
                vid.isCompleted
                  ? 'border-emerald-500/30 ring-1 ring-emerald-500/20'
                  : 'border-neutral-800 hover:border-neutral-700'
              }`}
            >
              <div>
                {/* Thumbnail Header */}
                <div className="relative aspect-video bg-neutral-950 overflow-hidden group">
                  <img
                    src={vid.thumbnail}
                    alt={vid.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />

                  <div className="absolute top-3 left-3 px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-[10px] font-mono text-neutral-300 border border-neutral-700">
                    Task #{idx + 1} • {vid.category}
                  </div>

                  <div className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded bg-amber-500/20 backdrop-blur-md border border-amber-500/40 text-amber-300 text-xs font-bold">
                    <Coins className="w-3.5 h-3.5" />
                    <span>Rs. {vid.rewardAmount > 0 ? vid.rewardAmount : (activePlan?.rewardPerVideo || '---')}</span>
                  </div>

                  {vid.isCompleted ? (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-[2px]">
                      <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-bold">
                        <CheckCircle2 className="w-4 h-4" />
                        Completed & Verified
                      </div>
                    </div>
                  ) : (
                    <div className="absolute bottom-3 left-3 flex items-center gap-1.5 text-[11px] text-neutral-300">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>Duration: {vid.durationSeconds}s verification</span>
                    </div>
                  )}
                </div>

                {/* Details */}
                <div className="p-5 space-y-2">
                  <div className="text-[11px] text-amber-400/90 font-medium uppercase tracking-wider">
                    Sponsor: {vid.sponsor}
                  </div>
                  <h3 className="text-base font-bold text-white line-clamp-2">
                    {vid.title}
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Watch the full {vid.durationSeconds}-second video task to verify playback and unlock your reward.
                  </p>
                </div>
              </div>

              {/* Action Button */}
              <div className="p-5 pt-0">
                {vid.isCompleted ? (
                  <button
                    disabled
                    className="w-full py-2.5 rounded-xl bg-neutral-800/80 border border-emerald-500/30 text-emerald-400 font-bold text-xs flex items-center justify-center gap-2 cursor-default"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Task Reward Claimed Today
                  </button>
                ) : requiresPlan ? (
                  <button
                    onClick={() => setActiveTab('plans')}
                    className="w-full py-2.5 rounded-xl bg-neutral-800 text-neutral-400 hover:text-white border border-neutral-700 font-semibold text-xs flex items-center justify-center gap-2"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    Activate Plan to Unlock
                  </button>
                ) : completedTodayCount >= maxDailyVideos ? (
                  <button
                    disabled
                    className="w-full py-2.5 rounded-xl bg-neutral-800 text-neutral-500 text-xs font-medium cursor-not-allowed"
                  >
                    Daily Limit Reached (2/2)
                  </button>
                ) : (
                  <button
                    onClick={() => startWatching(vid)}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-neutral-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all flex items-center justify-center gap-2"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    Watch Video Task ({vid.durationSeconds}s)
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Disclosed Transparent Earning Rules */}
      <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-400 text-xs flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <div className="font-bold text-white mb-1">Anti-Duplicate & Verification Policy</div>
          <p>
            ProfitNest utilizes cryptographic server-side validation to ensure video tasks are genuinely completed without automation or duplicate claims. Only one payout per video task per 24-hour cycle is awarded.
          </p>
        </div>
      </div>

      {/* Interactive Watch Video Modal */}
      {activeVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="bg-neutral-950 border border-amber-500/40 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl text-white">
            {/* Modal Header */}
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                  Verified Video Task
                </span>
                <h4 className="text-sm font-bold text-white truncate max-w-xs">
                  {activeVideo.title}
                </h4>
              </div>
              <button
                onClick={closeWatchModal}
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Video Player */}
            <div className="relative bg-black aspect-video flex items-center justify-center">
              <video
                ref={videoRef}
                src={activeVideo.videoUrl}
                autoPlay
                playsInline
                muted
                controls={false}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                className="w-full h-full object-contain"
              />

              {/* Progress Overlay */}
              <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black via-black/70 to-transparent flex flex-col gap-1.5">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-amber-400 font-bold">
                    {watchSeconds}s / {activeVideo.durationSeconds}s
                  </span>
                  <span className="text-neutral-300">
                    {canClaim ? 'Task Verification Complete!' : 'Watching task...'}
                  </span>
                </div>
                <div className="w-full bg-neutral-800 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-amber-400 h-full transition-all duration-300"
                    style={{
                      width: `${Math.min(100, (watchSeconds / activeVideo.durationSeconds) * 100)}%`,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Modal Footer & Claim Controls */}
            <div className="p-4 space-y-3">
              {claimError && (
                <div className="p-2.5 rounded-lg bg-red-950/70 border border-red-800 text-red-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{claimError}</span>
                </div>
              )}

              {claimSuccess && (
                <div className="p-2.5 rounded-lg bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{claimSuccess}</span>
                </div>
              )}

              <div className="flex items-center justify-between text-xs text-neutral-300">
                <span>Task Reward Amount:</span>
                <span className="font-bold text-amber-400 text-sm">
                  Rs. {activeVideo.rewardAmount > 0 ? activeVideo.rewardAmount : (activePlan?.rewardPerVideo || 0)}
                </span>
              </div>

              {canClaim ? (
                <button
                  onClick={handleClaimReward}
                  disabled={claiming}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white font-extrabold text-sm shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Coins className="w-4 h-4" />
                  {claiming ? 'Verifying with Server...' : 'Claim Verified Task Reward'}
                </button>
              ) : (
                <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-center text-xs text-neutral-400">
                  Please watch until the countdown finishes ({activeVideo.durationSeconds - watchSeconds}s remaining) to unlock your reward.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
