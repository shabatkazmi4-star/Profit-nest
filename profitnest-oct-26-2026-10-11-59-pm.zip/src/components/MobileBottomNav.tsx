import React from 'react';
import { Trophy, LayoutDashboard, PlaySquare, Users, User as UserIcon } from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ activeTab, setActiveTab }) => {
  // Requirement 13: On mobile, use a simple bottom navigation with exactly five options:
  // 1. Leaderboard
  // 2. Dashboard
  // 3. Watch Videos
  // 4. Referral
  // 5. Profile
  const tabs = [
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'videos', label: 'Watch Videos', icon: PlaySquare },
    { id: 'referral', label: 'Referral', icon: Users },
    { id: 'profile', label: 'Profile', icon: UserIcon },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-neutral-950/98 backdrop-blur-lg border-t border-amber-500/25 px-2 py-1 shadow-2xl">
      <div className="grid grid-cols-5 items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center py-1.5 px-1 relative transition-colors ${
                isActive ? 'text-amber-400' : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {isActive && (
                <span className="absolute top-0 w-8 h-[2px] bg-gradient-to-r from-amber-400 to-yellow-500 rounded-full" />
              )}
              <Icon className={`w-5 h-5 mb-0.5 ${isActive ? 'scale-110 text-amber-400' : 'text-neutral-400'}`} />
              <span className={`text-[10px] font-medium tracking-tight truncate max-w-full ${isActive ? 'font-bold text-amber-400' : 'text-neutral-400'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
