import React from 'react';
import {
  Coins,
  ArrowDownCircle,
  ArrowUpCircle,
  PlaySquare,
  Package,
  Users,
  History,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  Megaphone,
  Download,
  Smartphone,
} from 'lucide-react';
import { User, Plan, Transaction, Announcement } from '../types';

interface DashboardViewProps {
  user: User;
  activePlan: Plan | null;
  isPlanActive: boolean;
  remainingDays: number;
  completedToday: number;
  maxDailyVideos: number;
  recentTransactions: Transaction[];
  announcements: Announcement[];
  setActiveTab: (tab: string) => void;
  onRefresh: () => void;
  onOpenDownloadApp?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  activePlan,
  isPlanActive,
  remainingDays,
  completedToday,
  maxDailyVideos,
  recentTransactions,
  announcements,
  setActiveTab,
  onOpenDownloadApp,
}) => {
  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Announcement Banner if any */}
      {announcements.length > 0 && announcements[0] && (
        <div className="p-3.5 rounded-xl bg-gradient-to-r from-neutral-900 via-amber-950/40 to-neutral-900 border border-amber-500/30 flex items-center justify-between gap-3 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-400 text-neutral-950 shrink-0">
              <Megaphone className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wide mr-2">
                Announcement:
              </span>
              <span className="text-xs sm:text-sm text-neutral-200">
                {announcements[0].message}
              </span>
            </div>
          </div>
          <span className="text-[10px] text-neutral-400 hidden sm:inline whitespace-nowrap">
            Official Broadcast
          </span>
        </div>
      )}

      {/* Hero Welcome & Logo Bar */}
      <div className="relative overflow-hidden rounded-2xl bg-neutral-900/90 border border-amber-500/25 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="p-1 rounded bg-amber-400/20 text-amber-400 border border-amber-400/30">
                <Coins className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold tracking-wider uppercase text-amber-400">
                ProfitNest Member Dashboard
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Welcome, <span className="text-amber-400">{user.fullName}</span>
            </h1>
            <p className="text-xs sm:text-sm text-neutral-400">
              Mobile: <span className="font-mono text-neutral-300">{user.mobile}</span> • Referral Code: <span className="font-mono font-bold text-amber-400">{user.referralCode}</span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveTab('deposit')}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-bold text-xs sm:text-sm shadow-lg shadow-amber-500/20 hover:from-amber-300 hover:to-yellow-400 transition-all flex items-center gap-1.5"
            >
              <ArrowDownCircle className="w-4 h-4" />
              Deposit
            </button>
            <button
              onClick={() => setActiveTab('withdraw')}
              className="px-4 py-2.5 rounded-xl bg-neutral-800 text-white border border-neutral-700 hover:bg-neutral-700 font-semibold text-xs sm:text-sm transition-all flex items-center gap-1.5"
            >
              <ArrowUpCircle className="w-4 h-4 text-emerald-400" />
              Withdraw
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Account Balance */}
        <div className="rounded-xl bg-neutral-900 border border-amber-500/20 p-5 relative overflow-hidden shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-400">
              Account Balance
            </span>
            <div className="p-2 rounded-lg bg-amber-400/10 text-amber-400">
              <Coins className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-400 tracking-tight">
            Rs. {user.balance.toLocaleString()}
          </div>
          <p className="text-[11px] text-neutral-500 mt-1">Available for instant withdrawal</p>
        </div>

        {/* Total Verified Rewards */}
        <div className="rounded-xl bg-neutral-900 border border-neutral-800 p-5 relative overflow-hidden shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-400">
              Verified Rewards Balance
            </span>
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-white tracking-tight">
            Rs. {user.totalVerifiedRewards.toLocaleString()}
          </div>
          <p className="text-[11px] text-neutral-500 mt-1">All-time genuine verified earnings</p>
        </div>

        {/* Current Plan & Status */}
        <div className="rounded-xl bg-neutral-900 border border-neutral-800 p-5 relative overflow-hidden shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-400">
              Current Plan
            </span>
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
              <Package className="w-5 h-5" />
            </div>
          </div>
          <div className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            {activePlan ? activePlan.name : 'No Active Plan'}
            {isPlanActive ? (
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                Active
              </span>
            ) : (
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-400 border border-neutral-700">
                Inactive
              </span>
            )}
          </div>
          <p className="text-[11px] text-neutral-500 mt-1">
            {activePlan ? `Rs. ${activePlan.price} • 30 Days Cycle` : 'Choose a plan to start'}
          </p>
        </div>

        {/* Plan Expiry / Days Left */}
        <div className="rounded-xl bg-neutral-900 border border-neutral-800 p-5 relative overflow-hidden shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium uppercase tracking-wider text-neutral-400">
              Plan Expiry & Days
            </span>
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="text-xl font-bold text-white tracking-tight">
            {isPlanActive ? (
              <span className="text-amber-400">{remainingDays} Days Left</span>
            ) : (
              <span className="text-neutral-400">0 Days</span>
            )}
          </div>
          <p className="text-[11px] text-neutral-500 mt-1">
            {user.planExpiryDate
              ? `Expires: ${new Date(user.planExpiryDate).toLocaleDateString()}`
              : 'Requires verified activation'}
          </p>
        </div>
      </div>

      {/* Daily Video Tasks Progress Card */}
      <div className="rounded-2xl bg-neutral-900 border border-amber-500/25 p-6 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <PlaySquare className="w-5 h-5 text-amber-400" />
              <h2 className="text-base sm:text-lg font-bold text-white">Daily Video Tasks Progress</h2>
            </div>
            <p className="text-xs text-neutral-400">
              Complete your 2 daily eligible advertising tasks to claim verified rewards.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-xs text-neutral-400 block">Completed Today</span>
              <span className="text-lg font-extrabold text-amber-400">
                {completedToday} / {maxDailyVideos}
              </span>
            </div>
            <button
              onClick={() => setActiveTab('videos')}
              className="px-4 py-2 rounded-xl bg-amber-400 text-neutral-950 font-bold text-xs shadow-md shadow-amber-500/20 hover:bg-amber-300 transition-all flex items-center gap-1.5"
            >
              Watch Now
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-neutral-950 rounded-full h-3.5 p-0.5 border border-neutral-800">
          <div
            className="bg-gradient-to-r from-amber-400 to-yellow-500 h-full rounded-full transition-all duration-500"
            style={{ width: `${(completedToday / maxDailyVideos) * 100}%` }}
          />
        </div>

        {!isPlanActive && (
          <div className="mt-4 p-3 rounded-xl bg-neutral-950/70 border border-amber-500/20 flex items-center justify-between text-xs text-neutral-300">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>You do not have an active 30-day plan. Video rewards require an active plan.</span>
            </div>
            <button
              onClick={() => setActiveTab('plans')}
              className="font-bold text-amber-400 hover:underline shrink-0"
            >
              View 12 Plans
            </button>
          </div>
        )}
      </div>

      {/* Main Action Buttons Grid (Requirement 3: Every button must open its correct page) */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-3">
          Quick Actions
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <button
            onClick={() => setActiveTab('deposit')}
            className="flex flex-col items-center justify-center p-4 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/40 hover:bg-neutral-800/80 transition-all text-white group"
          >
            <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 mb-2 group-hover:scale-110 transition-transform">
              <ArrowDownCircle className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold">Deposit</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">Activate Plan</span>
          </button>

          <button
            onClick={() => setActiveTab('withdraw')}
            className="flex flex-col items-center justify-center p-4 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-emerald-500/40 hover:bg-neutral-800/80 transition-all text-white group"
          >
            <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 mb-2 group-hover:scale-110 transition-transform">
              <ArrowUpCircle className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold">Withdraw</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">Cashout balance</span>
          </button>

          <button
            onClick={() => setActiveTab('videos')}
            className="flex flex-col items-center justify-center p-4 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/40 hover:bg-neutral-800/80 transition-all text-white group"
          >
            <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 mb-2 group-hover:scale-110 transition-transform">
              <PlaySquare className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold">Watch Videos</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">2 daily tasks</span>
          </button>

          <button
            onClick={() => setActiveTab('plans')}
            className="flex flex-col items-center justify-center p-4 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-blue-500/40 hover:bg-neutral-800/80 transition-all text-white group"
          >
            <div className="p-3 rounded-xl bg-blue-500/10 text-blue-400 mb-2 group-hover:scale-110 transition-transform">
              <Package className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold">Plans</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">12 Available</span>
          </button>

          <button
            onClick={() => setActiveTab('referral')}
            className="flex flex-col items-center justify-center p-4 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-purple-500/40 hover:bg-neutral-800/80 transition-all text-white group"
          >
            <div className="p-3 rounded-xl bg-purple-500/10 text-purple-400 mb-2 group-hover:scale-110 transition-transform">
              <Users className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold">Referral</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">5% commission</span>
          </button>

          <button
            onClick={() => setActiveTab('transactions')}
            className="flex flex-col items-center justify-center p-4 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/40 hover:bg-neutral-800/80 transition-all text-white group"
          >
            <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 mb-2 group-hover:scale-110 transition-transform">
              <History className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold">History</span>
            <span className="text-[10px] text-neutral-400 mt-0.5">Transactions</span>
          </button>
        </div>
      </div>

      {/* Download App Feature Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-amber-950/30 via-neutral-900 to-neutral-900 border border-amber-500/30 p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-600 flex items-center justify-center text-neutral-950 shrink-0 shadow-lg shadow-amber-500/20">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white">ProfitNest Official Mobile App</h3>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-400 text-neutral-950">
                APK v1.0.4
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">
              Experience seamless video rewards, real-time push notices, and quick deposits & withdrawals on your phone.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenDownloadApp}
          className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-neutral-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all flex items-center justify-center gap-2 shrink-0"
        >
          <Download className="w-4 h-4" />
          Download App (8.4 MB)
        </button>
      </div>

      {/* Recent Transactions List */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-white">Recent Transactions</h3>
          </div>
          <button
            onClick={() => setActiveTab('transactions')}
            className="text-xs text-amber-400 hover:underline font-semibold"
          >
            View All Transactions →
          </button>
        </div>

        {recentTransactions.length === 0 ? (
          <div className="py-8 text-center text-xs text-neutral-400">
            No transactions yet. Complete video tasks or deposit to see records.
          </div>
        ) : (
          <div className="divide-y divide-neutral-800/60">
            {recentTransactions.map((tx) => (
              <div
                key={tx.id}
                className="py-3 flex items-center justify-between text-xs sm:text-sm"
              >
                <div>
                  <div className="font-semibold text-white flex items-center gap-2">
                    <span>{tx.description}</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                        tx.status === 'Completed' || tx.status === 'Approved' || tx.status === 'Paid'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : tx.status === 'Pending' || tx.status === 'Processing'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-red-500/10 text-red-400 border border-red-500/20'
                      }`}
                    >
                      {tx.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-400 font-mono mt-0.5">
                    {new Date(tx.createdAt).toLocaleString()} • ID: {tx.id}
                  </div>
                </div>
                <div
                  className={`font-bold text-sm ${
                    tx.type === 'Withdrawal' ? 'text-red-400' : 'text-emerald-400'
                  }`}
                >
                  {tx.type === 'Withdrawal' ? '-' : '+'}Rs. {tx.amount.toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Disclosed Transparent Earning Rules */}
      <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-400 text-xs space-y-1">
        <div className="flex items-center gap-1.5 text-amber-400 font-bold">
          <ShieldCheck className="w-4 h-4" />
          <span>ProfitNest Transparent Reward Policy</span>
        </div>
        <p>
          Rewards are earned exclusively from verified completed partner advertising and media engagement tasks. All earnings are calculated strictly per plan eligibility. Activation of plans requires manual verification of deposit Transaction ID by Shabahat Ali Kazmi.
        </p>
      </div>
    </div>
  );
};
