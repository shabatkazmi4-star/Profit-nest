import React, { useState } from 'react';
import {
  ArrowUpCircle,
  Coins,
  AlertCircle,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Building,
  Smartphone,
  Wallet,
} from 'lucide-react';
import { User, Withdrawal, PaymentMethodConfig } from '../types';
import { api } from '../services/api';

interface WithdrawViewProps {
  user: User;
  paymentMethods: PaymentMethodConfig[];
  withdrawals: Withdrawal[];
  availableBalance: number;
  onWithdrawalSubmitted: () => void;
  setActiveTab: (tab: string) => void;
}

export const WithdrawView: React.FC<WithdrawViewProps> = ({
  user,
  paymentMethods,
  withdrawals,
  availableBalance,
  onWithdrawalSubmitted,
  setActiveTab,
}) => {
  const [amount, setAmount] = useState('');
  const [accountHolder, setAccountHolder] = useState(user.fullName || '');
  const [paymentMethod, setPaymentMethod] = useState('Easypaisa');
  const [accountNumber, setAccountNumber] = useState(user.mobile || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount < 100) {
      setError('Minimum withdrawal amount is Rs. 100.');
      return;
    }
    if (numAmount > availableBalance) {
      setError(`Requested amount exceeds your available balance of Rs. ${availableBalance.toLocaleString()}.`);
      return;
    }
    if (!accountHolder.trim() || !accountNumber.trim()) {
      setError('Account holder name and account number are required.');
      return;
    }

    setLoading(true);
    try {
      const res = await api.createWithdrawal({
        amount: numAmount,
        accountHolder,
        paymentMethod,
        accountNumber,
      });
      setSuccess(res.message);
      setAmount('');
      onWithdrawalSubmitted();
    } catch (err: any) {
      setError(err.message || 'Withdrawal request failed.');
    } finally {
      setLoading(false);
    }
  };

  const setAllBalance = () => {
    if (availableBalance > 0) {
      setAmount(availableBalance.toString());
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-12">
      {/* Header */}
      <div className="text-center space-y-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase tracking-wider">
          <ArrowUpCircle className="w-3.5 h-3.5" />
          <span>Verified Funds Withdrawal</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Withdraw Your <span className="text-amber-400">Verified Earnings</span>
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400">
          Transfer your available balance to your Easypaisa, JazzCash, or Pakistani bank account. Payouts are reviewed and dispatched by Administrator Shabahat Ali Kazmi.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form */}
        <div className="lg:col-span-7 space-y-6">
          {/* Balance card */}
          <div className="rounded-2xl bg-neutral-900 border border-amber-500/30 p-6 shadow-xl flex items-center justify-between">
            <div>
              <span className="text-xs text-neutral-400 uppercase tracking-wider block">
                Available Withdrawable Balance
              </span>
              <span className="text-3xl font-black text-amber-400">
                Rs. {availableBalance.toLocaleString()}
              </span>
              <p className="text-[11px] text-neutral-500 mt-1">
                Total verified rewards: Rs. {user.totalVerifiedRewards.toLocaleString()}
              </p>
            </div>
            <div className="p-3 rounded-2xl bg-amber-400/10 text-amber-400 border border-amber-400/20">
              <Wallet className="w-8 h-8" />
            </div>
          </div>

          {/* Form Card */}
          <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl">
            <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
              <ArrowUpCircle className="w-4 h-4 text-emerald-400" />
              New Withdrawal Request
            </h3>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-800 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{error}</span>
              </div>
            )}

            {success && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{success}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-neutral-300">
                    Withdrawal Amount (PKR)
                  </label>
                  <button
                    type="button"
                    onClick={setAllBalance}
                    className="text-xs text-amber-400 font-bold hover:underline"
                  >
                    Withdraw All
                  </button>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-neutral-500 font-bold text-sm">Rs.</span>
                  <input
                    type="number"
                    required
                    min={100}
                    max={availableBalance}
                    placeholder="e.g. 500 (Minimum Rs. 100)"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Payout Method
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['Easypaisa', 'JazzCash', 'Bank Transfer'].map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                        paymentMethod === method
                          ? 'border-amber-400 bg-amber-500/15 text-white'
                          : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Account Holder Full Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="Name as registered on account"
                  value={accountHolder}
                  onChange={(e) => setAccountHolder(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Account Number / Mobile Number / IBAN
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    paymentMethod === 'Bank Transfer'
                      ? 'IBAN or Account Number with Bank Name'
                      : '03XXXXXXXXX'
                  }
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none font-mono"
                />
              </div>

              <button
                type="submit"
                disabled={loading || availableBalance < 100}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white font-extrabold text-sm shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <ArrowUpCircle className="w-5 h-5" />
                {loading ? 'Submitting Request...' : 'Submit Withdrawal Request'}
              </button>

              {availableBalance < 100 && (
                <p className="text-[11px] text-center text-neutral-500">
                  Minimum withdrawal threshold is Rs. 100. Watch videos to increase your balance.
                </p>
              )}
            </form>
          </div>
        </div>

        {/* Right Column: Withdrawal Policy & Status List */}
        <div className="lg:col-span-5 space-y-6">
          {/* Rules & Policy Card */}
          <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              Withdrawal Rules & Statuses
            </h3>
            <ul className="space-y-2 text-xs text-neutral-400">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <span className="font-semibold text-white">Pending:</span> Request submitted and queued for review.
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-400" />
                <span className="font-semibold text-white">Processing:</span> Being processed via bank/wallet gateway.
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="font-semibold text-white">Paid:</span> Successfully transferred with admin reference.
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-400" />
                <span className="font-semibold text-white">Rejected:</span> Discrepancy found; balance is refunded.
              </li>
            </ul>
            <div className="pt-2 border-t border-neutral-800 text-[11px] text-neutral-500">
              Only genuine, verified task rewards and legitimate referral bonuses can be withdrawn. Zero withdrawal fee applied.
            </div>
          </div>

          {/* User's Withdrawal History */}
          <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              Your Withdrawal History
            </h3>

            {withdrawals.length === 0 ? (
              <div className="py-6 text-center text-xs text-neutral-500">
                No withdrawal requests found.
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                {withdrawals.map((w) => (
                  <div
                    key={w.id}
                    className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-1.5 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">
                        Rs. {w.amount.toLocaleString()}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          w.status === 'Paid'
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                            : w.status === 'Processing'
                            ? 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
                            : w.status === 'Pending'
                            ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                            : 'bg-red-500/15 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {w.status}
                      </span>
                    </div>

                    <div className="text-[11px] text-neutral-400">
                      To: <span className="text-white">{w.accountHolder}</span> ({w.paymentMethod} - {w.accountNumber})
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-neutral-500 font-mono">
                      <span>ID: {w.id}</span>
                      <span>{new Date(w.createdAt).toLocaleDateString()}</span>
                    </div>

                    {w.adminReference && (
                      <div className="text-[11px] text-emerald-300/80 bg-neutral-900 p-1.5 rounded">
                        Ref: {w.adminReference}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
