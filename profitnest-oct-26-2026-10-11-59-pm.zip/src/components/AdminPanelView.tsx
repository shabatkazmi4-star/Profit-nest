import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Users,
  ArrowDownCircle,
  ArrowUpCircle,
  Settings,
  Megaphone,
  HelpCircle,
  FileText,
  Check,
  X,
  AlertCircle,
  CheckCircle2,
  Package,
  Coins,
  RefreshCw,
  Search,
  ExternalLink,
} from 'lucide-react';
import { api } from '../services/api';
import { User, Deposit, Withdrawal, SupportTicket, PlatformSettings, AdminLog, Plan } from '../types';

interface AdminPanelViewProps {
  adminUser: User;
  onRefreshData: () => void;
}

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({ adminUser, onRefreshData }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'deposits' | 'withdrawals' | 'users' | 'support' | 'announcements' | 'settings' | 'logs'>('overview');

  const [loading, setLoading] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Admin Data states
  const [overview, setOverview] = useState<any>(null);
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>([]);
  const [logs, setLogs] = useState<AdminLog[]>([]);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);

  // Action modals/forms state
  const [selectedDeposit, setSelectedDeposit] = useState<Deposit | null>(null);
  const [depositAdminNote, setDepositAdminNote] = useState('');

  const [selectedWithdrawal, setSelectedWithdrawal] = useState<Withdrawal | null>(null);
  const [withdrawalRef, setWithdrawalRef] = useState('');
  const [withdrawalStatus, setWithdrawalStatus] = useState<'Processing' | 'Paid' | 'Rejected'>('Paid');

  const [replyTicket, setReplyTicket] = useState<SupportTicket | null>(null);
  const [adminReplyText, setAdminReplyText] = useState('');

  const [newAnnTitle, setNewAnnTitle] = useState('');
  const [newAnnMessage, setNewAnnMessage] = useState('');

  // Settings form
  const [ownerName, setOwnerName] = useState('');
  const [ownerContact, setOwnerContact] = useState('');
  const [adminName, setAdminName] = useState('');
  const [adminContact, setAdminContact] = useState('');
  const [commissionRate, setCommissionRate] = useState(5);

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [ov, deps, withs, usrs, supp, lg, sett] = await Promise.all([
        api.getAdminOverview(),
        api.getAdminDeposits(),
        api.getAdminWithdrawals(),
        api.getAdminUsers(),
        api.getAdminSupport(),
        api.getAdminLogs(),
        api.getSettings(),
      ]);
      setOverview(ov);
      setDeposits(deps.deposits);
      setWithdrawals(withs.withdrawals);
      setUsers(usrs.users);
      setSupportTickets(supp.tickets);
      setLogs(lg.logs);
      setSettings(sett.settings);

      setOwnerName(sett.settings.ownerName);
      setOwnerContact(sett.settings.ownerContact);
      setAdminName(sett.settings.adminName);
      setAdminContact(sett.settings.adminContact);
      setCommissionRate(sett.settings.referralCommissionRate);
    } catch (err: any) {
      setActionError(err.message || 'Failed to load administrator data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleVerifyDeposit = async (action: 'approve' | 'reject') => {
    if (!selectedDeposit) return;
    try {
      const res = await api.verifyAdminDeposit(selectedDeposit.id, action, depositAdminNote);
      setActionSuccess(res.message);
      setSelectedDeposit(null);
      setDepositAdminNote('');
      fetchAdminData();
      onRefreshData();
    } catch (err: any) {
      setActionError(err.message || 'Deposit action failed.');
    }
  };

  const handleUpdateWithdrawal = async () => {
    if (!selectedWithdrawal) return;
    try {
      const res = await api.updateAdminWithdrawal(
        selectedWithdrawal.id,
        withdrawalStatus,
        withdrawalRef
      );
      setActionSuccess(res.message);
      setSelectedWithdrawal(null);
      setWithdrawalRef('');
      fetchAdminData();
      onRefreshData();
    } catch (err: any) {
      setActionError(err.message || 'Withdrawal update failed.');
    }
  };

  const handleReplyTicket = async () => {
    if (!replyTicket || !adminReplyText.trim()) return;
    try {
      await api.replyAdminSupport(replyTicket.id, adminReplyText, 'Resolved');
      setActionSuccess('Reply sent and ticket resolved.');
      setReplyTicket(null);
      setAdminReplyText('');
      fetchAdminData();
    } catch (err: any) {
      setActionError(err.message || 'Failed to send reply.');
    }
  };

  const handlePostAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnnTitle || !newAnnMessage) return;
    try {
      await api.postAdminAnnouncement(newAnnTitle, newAnnMessage);
      setActionSuccess('Broadcast announcement published to all users.');
      setNewAnnTitle('');
      setNewAnnMessage('');
      fetchAdminData();
    } catch (err: any) {
      setActionError(err.message || 'Failed to post announcement.');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.updateAdminSettings({
        ownerName,
        ownerContact,
        adminName,
        adminContact,
        referralCommissionRate: Number(commissionRate),
      });
      setActionSuccess('Settings and official contacts updated successfully.');
      fetchAdminData();
      onRefreshData();
    } catch (err: any) {
      setActionError(err.message || 'Failed to update settings.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-16">
      {/* Admin Top Header */}
      <div className="rounded-2xl bg-neutral-900 border border-amber-500/40 p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-600 text-neutral-950 font-bold shadow-lg shadow-amber-500/20">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-extrabold text-white">Administrator Control Center</h1>
              <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded bg-amber-400 text-neutral-950">
                Official Admin
              </span>
            </div>
            <p className="text-xs text-neutral-400">
              Admin: <span className="text-white font-semibold">{adminUser.fullName}</span> • Mobile: <span className="font-mono text-amber-400">{adminUser.mobile}</span>
            </p>
          </div>
        </div>

        <button
          onClick={fetchAdminData}
          disabled={loading}
          className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold flex items-center gap-2 border border-neutral-700 transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh Data
        </button>
      </div>

      {/* Global Alerts */}
      {actionSuccess && (
        <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{actionSuccess}</span>
          </div>
          <button onClick={() => setActionSuccess(null)} className="text-emerald-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {actionError && (
        <div className="p-3 rounded-xl bg-red-950/70 border border-red-800 text-red-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{actionError}</span>
          </div>
          <button onClick={() => setActionError(null)} className="text-red-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Admin Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-neutral-800 pb-2">
        {[
          { id: 'overview', label: 'Overview', icon: Coins },
          { id: 'deposits', label: `Deposits (${deposits.filter((d) => d.status === 'Pending').length} Pending)`, icon: ArrowDownCircle },
          { id: 'withdrawals', label: `Withdrawals (${withdrawals.filter((w) => w.status === 'Pending').length} Pending)`, icon: ArrowUpCircle },
          { id: 'users', label: `Users (${users.length})`, icon: Users },
          { id: 'support', label: `Support (${supportTickets.filter((t) => t.status === 'Open').length} Open)`, icon: HelpCircle },
          { id: 'announcements', label: 'Broadcast', icon: Megaphone },
          { id: 'settings', label: 'Contacts & Payments', icon: Settings },
          { id: 'logs', label: 'Audit Trail', icon: FileText },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                isActive
                  ? 'bg-amber-400 text-neutral-950 shadow-md shadow-amber-500/20'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && overview && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                Total Registered Members
              </span>
              <div className="text-3xl font-black text-white">{overview.totalUsers}</div>
              <span className="text-[11px] text-neutral-500 mt-1 block">Active user accounts</span>
            </div>

            <div className="p-5 rounded-2xl bg-neutral-900 border border-amber-500/30">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                Active 30-Day Plans
              </span>
              <div className="text-3xl font-black text-amber-400">{overview.activePlansCount}</div>
              <span className="text-[11px] text-neutral-500 mt-1 block">Verified plan holders</span>
            </div>

            <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                Pending Deposits
              </span>
              <div className="text-3xl font-black text-amber-300">{overview.pendingDeposits}</div>
              <span className="text-[11px] text-neutral-500 mt-1 block">Awaiting TID review</span>
            </div>

            <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                Pending Withdrawals
              </span>
              <div className="text-3xl font-black text-blue-400">{overview.pendingWithdrawals}</div>
              <span className="text-[11px] text-neutral-500 mt-1 block">Awaiting payment payout</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                Total Confirmed Deposits
              </span>
              <div className="text-3xl font-black text-emerald-400">
                Rs. {overview.totalDeposited.toLocaleString()}
              </div>
              <p className="text-xs text-neutral-500 mt-2">
                Total plan activation funds verified on ledger.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                Total Paid Withdrawals
              </span>
              <div className="text-3xl font-black text-white">
                Rs. {overview.totalPaidOut.toLocaleString()}
              </div>
              <p className="text-xs text-neutral-500 mt-2">
                Total genuine rewards paid out to members.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Manage Deposits */}
      {activeTab === 'deposits' && (
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ArrowDownCircle className="w-5 h-5 text-amber-400" />
              Deposit Requests Verification
            </h3>
            <span className="text-xs text-neutral-400">
              Approving a deposit automatically activates the user's 30-day plan.
            </span>
          </div>

          {deposits.length === 0 ? (
            <div className="py-12 text-center text-xs text-neutral-500">
              No deposit requests found in the ledger.
            </div>
          ) : (
            <div className="divide-y divide-neutral-800 overflow-x-auto">
              <div className="min-w-[650px] space-y-3">
                {deposits.map((dep) => (
                  <div
                    key={dep.id}
                    className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">
                          Rs. {dep.amount.toLocaleString()}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 font-semibold text-[11px]">
                          {dep.planName || `Plan ${dep.planId}`}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            dep.status === 'Approved'
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : dep.status === 'Pending'
                              ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                              : 'bg-red-500/15 text-red-400 border border-red-500/30'
                          }`}
                        >
                          {dep.status}
                        </span>
                      </div>

                      <div className="text-neutral-300">
                        User: <span className="font-semibold text-white">{dep.userName}</span> ({dep.userMobile})
                      </div>

                      <div className="font-mono text-neutral-400 text-[11px]">
                        TID: <span className="text-amber-400 font-bold">{dep.transactionId}</span> • Method: {dep.paymentMethod} (Sender: {dep.senderNumber})
                      </div>

                      {dep.notes && <div className="text-[11px] text-neutral-400 italic">User Note: {dep.notes}</div>}
                      {dep.adminNote && <div className="text-[11px] text-amber-300/80">Admin Note: {dep.adminNote}</div>}
                    </div>

                    <div>
                      {dep.status === 'Pending' ? (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setSelectedDeposit(dep);
                              setDepositAdminNote('Verified & Approved on Bank Ledger');
                            }}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-colors"
                          >
                            Verify & Activate
                          </button>
                          <button
                            onClick={() => {
                              setSelectedDeposit(dep);
                              setDepositAdminNote('Invalid Transaction ID or payment not received');
                            }}
                            className="px-3 py-1.5 rounded-lg bg-red-900/60 hover:bg-red-800 text-red-200 font-bold text-xs transition-colors"
                          >
                            Reject
                          </button>
                        </div>
                      ) : (
                        <span className="text-[11px] text-neutral-500">Processed</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Manage Withdrawals */}
      {activeTab === 'withdrawals' && (
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ArrowUpCircle className="w-5 h-5 text-emerald-400" />
              Withdrawal Payout Requests
            </h3>
            <span className="text-xs text-neutral-400">
              Mark as Paid only after transferring money to the user's account.
            </span>
          </div>

          {withdrawals.length === 0 ? (
            <div className="py-12 text-center text-xs text-neutral-500">
              No withdrawal requests recorded.
            </div>
          ) : (
            <div className="space-y-3">
              {withdrawals.map((w) => (
                <div
                  key={w.id}
                  className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-base">
                        Rs. {w.amount.toLocaleString()}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          w.status === 'Paid'
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                            : w.status === 'Processing'
                            ? 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
                            : w.status === 'Pending'
                            ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                            : 'bg-red-500/15 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {w.status}
                      </span>
                    </div>

                    <div className="text-neutral-300">
                      Beneficiary: <span className="font-bold text-white">{w.accountHolder}</span> • Method: <span className="text-amber-400 font-semibold">{w.paymentMethod}</span>
                    </div>

                    <div className="font-mono text-neutral-400 text-[11px]">
                      Account: {w.accountNumber} • Requested by: {w.userName} ({w.userMobile})
                    </div>

                    {w.adminReference && (
                      <div className="text-[11px] text-emerald-300/80 font-mono">
                        Payout Ref: {w.adminReference}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setSelectedWithdrawal(w);
                        setWithdrawalStatus('Paid');
                        setWithdrawalRef(`Paid via ${w.paymentMethod} from Shaheena bukhari account`);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                    >
                      Update Payout Status
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Registered Users */}
      {activeTab === 'users' && (
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-400" />
            Registered Members Directory ({users.length})
          </h3>

          <div className="divide-y divide-neutral-800 overflow-x-auto">
            <div className="min-w-[600px] space-y-2">
              {users.map((u) => (
                <div
                  key={u.id}
                  className="py-3 px-4 rounded-xl bg-neutral-950 border border-neutral-800/80 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-bold text-white text-sm flex items-center gap-2">
                      <span>{u.fullName}</span>
                      {u.role === 'admin' && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-400 text-neutral-950 font-black uppercase">
                          Admin
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-neutral-400 font-mono">
                      Mobile: {u.mobile} • Code: {u.referralCode}
                    </div>
                    <div className="text-[10px] text-neutral-500">
                      Joined: {new Date(u.createdAt).toLocaleDateString()}
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-bold text-amber-400 text-sm">
                      Balance: Rs. {u.balance.toLocaleString()}
                    </div>
                    <div className="text-[11px] text-neutral-400">
                      Active: {u.activePlanId ? `Plan ${u.activePlanId}` : 'No Active Plan'}
                    </div>
                    <div className="text-[10px] text-emerald-400 font-semibold">
                      Total Rewards: Rs. {u.totalVerifiedRewards.toLocaleString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Support Tickets */}
      {activeTab === 'support' && (
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-amber-400" />
            Customer Support Tickets
          </h3>

          {supportTickets.length === 0 ? (
            <div className="py-12 text-center text-xs text-neutral-500">
              No support tickets found.
            </div>
          ) : (
            <div className="space-y-3">
              {supportTickets.map((t) => (
                <div
                  key={t.id}
                  className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-xs space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white text-sm block">{t.subject}</span>
                      <span className="text-[11px] text-neutral-400 font-mono">
                        From: {t.userName} ({t.mobile}) • Category: {t.category}
                      </span>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        t.status === 'Resolved'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {t.status}
                    </span>
                  </div>

                  <p className="text-neutral-300 bg-neutral-900/60 p-2.5 rounded-lg border border-neutral-800">
                    {t.message}
                  </p>

                  {t.adminReply && (
                    <div className="p-2 rounded-lg bg-neutral-900 border border-amber-500/20 text-amber-300 text-[11px]">
                      <span className="font-bold text-amber-400 block mb-0.5">Your Previous Reply:</span>
                      {t.adminReply}
                    </div>
                  )}

                  <div className="pt-1 flex items-center justify-end">
                    <button
                      onClick={() => {
                        setReplyTicket(t);
                        setAdminReplyText(t.adminReply || '');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-amber-400 text-neutral-950 font-bold text-xs hover:bg-amber-300"
                    >
                      {t.adminReply ? 'Update Reply' : 'Send Admin Reply'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 6: Broadcast Announcements */}
      {activeTab === 'announcements' && (
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-6">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Megaphone className="w-5 h-5 text-amber-400" />
            Send Broadcast Announcement
          </h3>
          <p className="text-xs text-neutral-400">
            Publish official announcements that appear directly at the top of every member's dashboard.
          </p>

          <form onSubmit={handlePostAnnouncement} className="space-y-4 max-w-xl">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Announcement Headline
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Deposit processing schedule update"
                value={newAnnTitle}
                onChange={(e) => setNewAnnTitle(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Announcement Message
              </label>
              <textarea
                required
                rows={3}
                placeholder="Write the message to display on all member dashboards..."
                value={newAnnMessage}
                onChange={(e) => setNewAnnMessage(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2 text-xs text-white"
              />
            </div>

            <button
              type="submit"
              className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-bold text-xs"
            >
              Publish Broadcast Banner
            </button>
          </form>
        </div>
      )}

      {/* Tab 7: Settings & Official Contacts */}
      {activeTab === 'settings' && (
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-6">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-amber-400" />
            Configure Contacts & Platform Details
          </h3>

          <form onSubmit={handleSaveSettings} className="space-y-4 max-w-xl">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Owner Name</label>
                <input
                  type="text"
                  required
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Owner Contact
                </label>
                <input
                  type="text"
                  required
                  value={ownerContact}
                  onChange={(e) => setOwnerContact(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2 text-xs text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Admin Name</label>
                <input
                  type="text"
                  required
                  value={adminName}
                  onChange={(e) => setAdminName(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Admin Contact
                </label>
                <input
                  type="text"
                  required
                  value={adminContact}
                  onChange={(e) => setAdminContact(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2 text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Referral Commission Percentage (%)
              </label>
              <input
                type="number"
                min={1}
                max={50}
                value={commissionRate}
                onChange={(e) => setCommissionRate(Number(e.target.value))}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2 text-xs text-white"
              />
            </div>

            <button
              type="submit"
              className="py-2.5 px-6 rounded-xl bg-amber-400 text-neutral-950 font-bold text-xs hover:bg-amber-300"
            >
              Save Platform Settings
            </button>
          </form>
        </div>
      )}

      {/* Tab 8: Audit Logs */}
      {activeTab === 'logs' && (
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            Administrator Action Audit Trail
          </h3>

          {logs.length === 0 ? (
            <div className="py-12 text-center text-xs text-neutral-500">
              No audit logs recorded yet.
            </div>
          ) : (
            <div className="divide-y divide-neutral-800">
              {logs.map((lg) => (
                <div key={lg.id} className="py-3 text-xs flex items-center justify-between">
                  <div>
                    <span className="font-bold text-amber-400 font-mono text-[11px] block">
                      [{lg.action}]
                    </span>
                    <p className="text-neutral-200 mt-0.5">{lg.details}</p>
                    <span className="text-[10px] text-neutral-500 font-mono">
                      By: {lg.adminMobile} • {new Date(lg.createdAt).toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal: Verify Deposit */}
      {selectedDeposit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-neutral-950 border border-amber-500/40 rounded-2xl p-6 max-w-md w-full text-white space-y-4">
            <h3 className="text-base font-bold text-amber-400">
              Verify Deposit Request
            </h3>
            <div className="p-3 bg-neutral-900 rounded-xl text-xs space-y-1">
              <div>User: {selectedDeposit.userName} ({selectedDeposit.userMobile})</div>
              <div>Amount: <span className="font-bold text-emerald-400">Rs. {selectedDeposit.amount.toLocaleString()}</span> for Plan #{selectedDeposit.planId}</div>
              <div className="font-mono text-amber-300">TID: {selectedDeposit.transactionId}</div>
              <div>Method: {selectedDeposit.paymentMethod} (Sender: {selectedDeposit.senderNumber})</div>
            </div>

            <div>
              <label className="block text-xs text-neutral-400 mb-1">Admin Verification Note</label>
              <input
                type="text"
                value={depositAdminNote}
                onChange={(e) => setDepositAdminNote(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => handleVerifyDeposit('approve')}
                className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
              >
                Approve & Activate Plan
              </button>
              <button
                onClick={() => handleVerifyDeposit('reject')}
                className="py-2.5 rounded-xl bg-red-900/80 hover:bg-red-800 text-white font-bold text-xs"
              >
                Reject Request
              </button>
            </div>

            <button
              onClick={() => setSelectedDeposit(null)}
              className="w-full text-center text-xs text-neutral-400 hover:text-white pt-1"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Modal: Update Withdrawal */}
      {selectedWithdrawal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-neutral-950 border border-amber-500/40 rounded-2xl p-6 max-w-md w-full text-white space-y-4">
            <h3 className="text-base font-bold text-amber-400">
              Process Withdrawal Payout
            </h3>
            <div className="p-3 bg-neutral-900 rounded-xl text-xs space-y-1">
              <div>Beneficiary: {selectedWithdrawal.accountHolder}</div>
              <div>Account: {selectedWithdrawal.accountNumber} ({selectedWithdrawal.paymentMethod})</div>
              <div>Amount: <span className="font-bold text-amber-400">Rs. {selectedWithdrawal.amount.toLocaleString()}</span></div>
            </div>

            <div>
              <label className="block text-xs text-neutral-400 mb-1">New Status</label>
              <select
                value={withdrawalStatus}
                onChange={(e) => setWithdrawalStatus(e.target.value as any)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="Paid">Paid (Cash Transferred)</option>
                <option value="Processing">Processing (In Queue)</option>
                <option value="Rejected">Rejected (Refund to user balance)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-neutral-400 mb-1">Admin Reference / Payment TID</label>
              <input
                type="text"
                placeholder="e.g. Sent via Easypaisa Trx #123456"
                value={withdrawalRef}
                onChange={(e) => setWithdrawalRef(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <button
              onClick={handleUpdateWithdrawal}
              className="w-full py-2.5 rounded-xl bg-amber-400 text-neutral-950 font-bold text-xs hover:bg-amber-300"
            >
              Save Payout Status
            </button>

            <button
              onClick={() => setSelectedWithdrawal(null)}
              className="w-full text-center text-xs text-neutral-400 hover:text-white pt-1"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Modal: Reply Support Ticket */}
      {replyTicket && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-neutral-950 border border-amber-500/40 rounded-2xl p-6 max-w-md w-full text-white space-y-4">
            <h3 className="text-base font-bold text-amber-400">
              Reply to Support Ticket
            </h3>
            <div className="p-3 bg-neutral-900 rounded-xl text-xs space-y-1">
              <div className="font-bold text-white">{replyTicket.subject}</div>
              <div className="text-neutral-400">{replyTicket.message}</div>
            </div>

            <div>
              <label className="block text-xs text-neutral-400 mb-1">Your Administrator Reply</label>
              <textarea
                rows={4}
                value={adminReplyText}
                onChange={(e) => setAdminReplyText(e.target.value)}
                placeholder="Enter helpful reply for user..."
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white resize-none"
              />
            </div>

            <button
              onClick={handleReplyTicket}
              className="w-full py-2.5 rounded-xl bg-amber-400 text-neutral-950 font-bold text-xs hover:bg-amber-300"
            >
              Send Reply & Mark Resolved
            </button>

            <button
              onClick={() => setReplyTicket(null)}
              className="w-full text-center text-xs text-neutral-400 hover:text-white pt-1"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
