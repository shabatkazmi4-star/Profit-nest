import React from 'react';
import { Package, CheckCircle2, ShieldAlert, ArrowRight, Sparkles, Clock, Check } from 'lucide-react';
import { Plan, User } from '../types';

interface PlansViewProps {
  plans: Plan[];
  user: User | null;
  onSelectPlan: (planId: number) => void;
  setActiveTab: (tab: string) => void;
}

export const PlansView: React.FC<PlansViewProps> = ({
  plans,
  user,
  onSelectPlan,
  setActiveTab,
}) => {
  const handlePlanClick = (planId: number) => {
    onSelectPlan(planId);
    setActiveTab('deposit');
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="text-center space-y-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <Package className="w-3.5 h-3.5" />
          <span>ProfitNest Official Plans</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Choose Your <span className="text-amber-400">30-Day Plan</span>
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400">
          Select any of the 12 available plans. Every plan has a fixed 30-day validity and grants access to 2 daily verified video reward tasks.
        </p>
      </div>

      {/* Required Legal Disclaimer */}
      <div className="p-4 rounded-xl bg-neutral-900 border border-amber-500/30 text-xs text-neutral-300 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <div className="font-bold text-amber-400 mb-0.5">Important Compliance Notice</div>
          <p className="text-neutral-400 leading-relaxed">
            ProfitNest does not promise guaranteed profits, fixed investment returns, or financial interest. Video rewards are earned solely from genuine completion of verified advertising partner tasks. All plans are activated manually only after confirmed payment verification by Administrator Shabahat Ali Kazmi.
          </p>
        </div>
      </div>

      {/* 12 Plans Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {plans.map((plan) => {
          const isCurrentPlan = user?.activePlanId === plan.id;
          return (
            <div
              key={plan.id}
              className={`rounded-2xl p-5 bg-neutral-900 border transition-all duration-200 flex flex-col justify-between relative ${
                isCurrentPlan
                  ? 'border-amber-400 ring-1 ring-amber-400/50 shadow-lg shadow-amber-500/10'
                  : 'border-neutral-800 hover:border-neutral-700'
              }`}
            >
              {isCurrentPlan && (
                <div className="absolute -top-3 right-4 px-2.5 py-0.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-extrabold text-[10px] rounded-full uppercase tracking-wider shadow-md">
                  Current Plan
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    Plan #{plan.id}
                  </span>
                  <div className="flex items-center gap-1 text-[11px] text-neutral-400 bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800">
                    <Clock className="w-3 h-3 text-amber-400" />
                    <span>30 Days Validity</span>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="text-2xl font-black text-white">
                    Rs. {plan.price.toLocaleString()}
                  </div>
                  <span className="text-[11px] text-neutral-500 font-medium">
                    One-time activation fee for 30 days
                  </span>
                </div>

                {/* Plan specs */}
                <div className="space-y-2 mb-6 pt-3 border-t border-neutral-800 text-xs">
                  <div className="flex items-center justify-between text-neutral-300">
                    <span>Daily Video Tasks:</span>
                    <span className="font-bold text-white">2 Tasks / Day</span>
                  </div>
                  <div className="flex items-center justify-between text-neutral-300">
                    <span>Reward Per Video:</span>
                    <span className="font-bold text-amber-400">
                      Rs. {plan.rewardPerVideo.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-neutral-300">
                    <span>Max Daily Reward:</span>
                    <span className="font-bold text-emerald-400">
                      Rs. {plan.dailyEarning.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-neutral-400 text-[11px]">
                    <span>Total 30-Day Potential:</span>
                    <span className="font-semibold text-neutral-300">
                      Rs. {(plan.dailyEarning * 30).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div>
                {isCurrentPlan ? (
                  <button
                    disabled
                    className="w-full py-2.5 rounded-xl bg-neutral-800 border border-amber-500/30 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 cursor-default"
                  >
                    <Check className="w-4 h-4 text-emerald-400" />
                    Active Plan
                  </button>
                ) : (
                  <button
                    onClick={() => handlePlanClick(plan.id)}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-neutral-950 font-bold text-xs shadow-md shadow-amber-500/10 transition-all flex items-center justify-center gap-1.5"
                  >
                    Select Plan {plan.id}
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
                <p className="text-[10px] text-center text-neutral-500 mt-2">
                  Activation upon payment verification
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
