import React, { useState } from 'react';
import {
  User as UserIcon,
  Phone,
  Calendar,
  Tag,
  Package,
  Clock,
  Lock,
  LogOut,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  ArrowUpRight,
  ShieldCheck,
} from 'lucide-react';
import { User, Plan } from '../types';
import { api } from '../services/api';

interface ProfileViewProps {
  user: User;
  activePlan: Plan | null;
  isPlanActive: boolean;
  remainingDays: number;
  onLogout: () => void;
  setActiveTab: (tab: string) => void;
  onRefresh: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  activePlan,
  isPlanActive,
  remainingDays,
  onLogout,
  setActiveTab,
  onRefresh,
}) => {
  // Password change state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [pwLoading, setPwLoading] = useState(false);
  const [pwError, setPwError] = useState<string | null>(null);
  const [pwSuccess, setPwSuccess] = useState<string | null>(null);

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwError(null);
    setPwSuccess(null);

    if (newPassword !== confirmNewPassword) {
      setPwError('New passwords do not match.');
      return;
    }

    setPwLoading(true);
    try {
      const res = await api.changePassword({
        oldPassword,
        newPassword,
        confirmNewPassword,
      });
      setPwSuccess(res.message);
      setOldPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (err: any) {
      setPwError(err.message || 'Failed to change password.');
    } finally {
      setPwLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-12">
      {/* Header */}
      <div className="text-center space-y-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <UserIcon className="w-3.5 h-3.5" />
          <span>Account & Security</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          User <span className="text-amber-400">Profile</span>
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400">
          Manage your account credentials, view 30-day plan status, renew or upgrade, and configure security.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Profile Details & 30-Day Plan Engine */}
        <div className="lg:col-span-7 space-y-6">
          {/* User Info Card */}
          <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-600 flex items-center justify-center text-neutral-950 font-black text-xl shadow-md">
                  {user.fullName.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white">{user.fullName}</h3>
                  <div className="text-xs text-neutral-400 flex items-center gap-1.5">
                    <span className="font-mono">{user.mobile}</span>
                    <span>•</span>
                    <span className="capitalize text-amber-400 font-semibold">{user.role}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={onLogout}
                className="px-3 py-1.5 rounded-lg bg-neutral-950 border border-red-900/40 text-red-400 hover:bg-red-950/30 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                Logout
              </button>
            </div>

            {/* Account meta fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase tracking-wider block mb-1">
                  Full Name
                </span>
                <span className="font-bold text-white text-sm">{user.fullName}</span>
              </div>

              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase tracking-wider block mb-1">
                  Registered Mobile
                </span>
                <span className="font-mono font-bold text-white text-sm">{user.mobile}</span>
              </div>

              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase tracking-wider block mb-1">
                  Registration Date
                </span>
                <span className="font-mono text-neutral-300">
                  {new Date(user.createdAt).toLocaleDateString()}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase tracking-wider block mb-1">
                  Referral Code
                </span>
                <span className="font-mono font-bold text-amber-400">{user.referralCode}</span>
              </div>
            </div>
          </div>

          {/* Thirty-Day Plan System Section (Requirement 12) */}
          <div className="rounded-2xl bg-neutral-900 border border-amber-500/30 p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold text-white">Thirty-Day Plan Status</h3>
              </div>
              <span
                className={`text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full ${
                  isPlanActive
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                }`}
              >
                {isPlanActive ? 'Active Plan' : 'No Active Plan / Expired'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase tracking-wider block mb-1">
                  Current Plan
                </span>
                <span className="font-extrabold text-white text-base">
                  {activePlan ? `${activePlan.name} (Rs. ${activePlan.price.toLocaleString()})` : 'None'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase tracking-wider block mb-1">
                  Remaining Validity
                </span>
                <span className="font-black text-amber-400 text-base">
                  {isPlanActive ? `${remainingDays} Days Remaining` : '0 Days'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase tracking-wider block mb-1">
                  Plan Activation Date
                </span>
                <span className="font-mono text-neutral-300">
                  {user.planActivationDate
                    ? new Date(user.planActivationDate).toLocaleString()
                    : 'Not activated yet'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-[10px] text-neutral-500 uppercase tracking-wider block mb-1">
                  Plan Expiry Date
                </span>
                <span className="font-mono text-neutral-300">
                  {user.planExpiryDate
                    ? new Date(user.planExpiryDate).toLocaleString()
                    : 'N/A'}
                </span>
              </div>
            </div>

            {/* Plan Action Buttons: Renew & Upgrade (Requirement 12) */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <button
                onClick={() => setActiveTab('deposit')}
                className="w-full sm:w-1/2 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-bold text-xs shadow-md shadow-amber-500/20 hover:from-amber-300 hover:to-yellow-400 transition-all flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Renew Plan (30 Days)
              </button>
              <button
                onClick={() => setActiveTab('plans')}
                className="w-full sm:w-1/2 py-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs border border-neutral-700 transition-all flex items-center justify-center gap-2"
              >
                <ArrowUpRight className="w-4 h-4 text-amber-400" />
                Upgrade to Higher Plan
              </button>
            </div>

            <p className="text-[11px] text-neutral-500">
              * Renewals and upgrades are never auto-charged. They activate strictly upon verified payment confirmation. Your balance, verified rewards, and transaction history are permanently preserved even after plan expiry.
            </p>
          </div>
        </div>

        {/* Right Column: Change Password */}
        <div className="lg:col-span-5 space-y-6">
          <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400" />
              Change Password
            </h3>

            {pwError && (
              <div className="p-3 rounded-xl bg-red-950/60 border border-red-800 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{pwError}</span>
              </div>
            )}

            {pwSuccess && (
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{pwSuccess}</span>
              </div>
            )}

            <form onSubmit={handlePasswordChange} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  required
                  placeholder="Enter current password"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  required
                  placeholder="Min 6 characters"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  required
                  placeholder="Re-type new password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={pwLoading}
                className="w-full py-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs border border-neutral-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Lock className="w-4 h-4 text-amber-400" />
                {pwLoading ? 'Updating Password...' : 'Update Password'}
              </button>
            </form>
          </div>

          {/* Security policy badge */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-400 text-xs flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-white mb-0.5">Password Encryption</div>
              <p>
                All account passwords are encrypted using SHA-256 with platform salting. Passwords are never stored in plain text.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
