import React, { useState } from 'react';
import {
  History,
  ArrowDownCircle,
  ArrowUpCircle,
  PlaySquare,
  Users,
  Search,
  Filter,
} from 'lucide-react';
import { Transaction } from '../types';

interface TransactionHistoryViewProps {
  transactions: Transaction[];
}

export const TransactionHistoryView: React.FC<TransactionHistoryViewProps> = ({ transactions }) => {
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = transactions.filter((t) => {
    const matchesType =
      filterType === 'all' ||
      (filterType === 'Deposit' && t.type === 'Deposit') ||
      (filterType === 'Withdrawal' && t.type === 'Withdrawal') ||
      (filterType === 'Video Reward' && t.type === 'Video Reward') ||
      (filterType === 'Referral Reward' && t.type === 'Referral Reward');

    const matchesSearch =
      !searchQuery ||
      t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesType && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="text-center space-y-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <History className="w-3.5 h-3.5" />
          <span>Ledger & Records</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Transaction <span className="text-amber-400">History</span>
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400">
          Complete transparent record of all your deposits, withdrawals, verified video rewards, and referral bonuses.
        </p>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 shadow-lg space-y-3 sm:space-y-0 sm:flex items-center justify-between gap-4">
        {/* Category Filters */}
        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: 'all', label: 'All Transactions' },
            { id: 'Deposit', label: 'Deposits', icon: ArrowDownCircle },
            { id: 'Withdrawal', label: 'Withdrawals', icon: ArrowUpCircle },
            { id: 'Video Reward', label: 'Video Rewards', icon: PlaySquare },
            { id: 'Referral Reward', label: 'Referral Rewards', icon: Users },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setFilterType(item.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                filterType === item.id
                  ? 'bg-amber-400 text-neutral-950 shadow-sm'
                  : 'bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-500" />
          <input
            type="text"
            placeholder="Search by ID or description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Transactions List */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
        {filtered.length === 0 ? (
          <div className="py-12 text-center text-xs text-neutral-500">
            No transactions matching this filter.
          </div>
        ) : (
          <div>
            {/* Desktop Table Header */}
            <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3.5 bg-neutral-950 border-b border-neutral-800 text-[11px] font-bold uppercase tracking-wider text-neutral-400">
              <div className="col-span-3">Transaction ID / Type</div>
              <div className="col-span-4">Description</div>
              <div className="col-span-2">Date & Time</div>
              <div className="col-span-1">Status</div>
              <div className="col-span-2 text-right">Amount</div>
            </div>

            {/* List Rows */}
            <div className="divide-y divide-neutral-800/70">
              {filtered.map((t) => {
                const isNegative = t.type === 'Withdrawal';
                return (
                  <div
                    key={t.id}
                    className="p-4 sm:px-6 hover:bg-neutral-800/40 transition-colors"
                  >
                    {/* Desktop View */}
                    <div className="hidden md:grid grid-cols-12 gap-4 items-center text-xs">
                      <div className="col-span-3">
                        <div className="font-mono font-bold text-white">{t.id}</div>
                        <span className="text-[11px] text-amber-400/90 font-medium">
                          {t.type}
                        </span>
                      </div>
                      <div className="col-span-4 text-neutral-300 truncate">
                        {t.description}
                      </div>
                      <div className="col-span-2 text-neutral-400 font-mono text-[11px]">
                        {new Date(t.createdAt).toLocaleString()}
                      </div>
                      <div className="col-span-1">
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold uppercase ${
                            t.status === 'Completed' || t.status === 'Approved' || t.status === 'Paid'
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : t.status === 'Pending' || t.status === 'Processing'
                              ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                              : 'bg-red-500/15 text-red-400 border border-red-500/30'
                          }`}
                        >
                          {t.status}
                        </span>
                      </div>
                      <div
                        className={`col-span-2 text-right font-black text-sm font-mono ${
                          isNegative ? 'text-red-400' : 'text-emerald-400'
                        }`}
                      >
                        {isNegative ? '-' : '+'}Rs. {t.amount.toLocaleString()}
                      </div>
                    </div>

                    {/* Mobile Friendly Card View */}
                    <div className="md:hidden space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] uppercase font-bold text-amber-400">
                            {t.type}
                          </span>
                          <span
                            className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold uppercase ${
                              t.status === 'Completed' || t.status === 'Approved' || t.status === 'Paid'
                                ? 'bg-emerald-500/15 text-emerald-400'
                                : t.status === 'Pending' || t.status === 'Processing'
                                ? 'bg-amber-500/15 text-amber-400'
                                : 'bg-red-500/15 text-red-400'
                            }`}
                          >
                            {t.status}
                          </span>
                        </div>
                        <div
                          className={`font-black text-sm font-mono ${
                            isNegative ? 'text-red-400' : 'text-emerald-400'
                          }`}
                        >
                          {isNegative ? '-' : '+'}Rs. {t.amount.toLocaleString()}
                        </div>
                      </div>

                      <div className="text-xs text-white font-medium">{t.description}</div>

                      <div className="flex items-center justify-between text-[10px] text-neutral-500 font-mono pt-1">
                        <span>ID: {t.id}</span>
                        <span>{new Date(t.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
