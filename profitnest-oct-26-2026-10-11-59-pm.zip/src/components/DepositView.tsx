import React, { useState } from 'react';
import {
  ArrowDownCircle,
  Copy,
  Check,
  AlertCircle,
  CheckCircle2,
  Clock,
  HelpCircle,
  Building,
  Smartphone,
  ShieldCheck,
  Package,
} from 'lucide-react';
import { Plan, PaymentMethodConfig, Deposit, User } from '../types';
import { api } from '../services/api';

interface DepositViewProps {
  user: User;
  plans: Plan[];
  selectedPlanId: number;
  setSelectedPlanId: (id: number) => void;
  paymentMethods: PaymentMethodConfig[];
  deposits: Deposit[];
  onDepositSubmitted: () => void;
}

export const DepositView: React.FC<DepositViewProps> = ({
  user,
  plans,
  selectedPlanId,
  setSelectedPlanId,
  paymentMethods,
  deposits,
  onDepositSubmitted,
}) => {
  const [selectedMethodId, setSelectedMethodId] = useState<string>(
    paymentMethods[0]?.id || 'easypaisa'
  );
  const [senderNumber, setSenderNumber] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const selectedPlan = plans.find((p) => p.id === selectedPlanId) || plans[0];
  const activeMethod = paymentMethods.find((m) => m.id === selectedMethodId) || paymentMethods[0];

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!transactionId.trim()) {
      setError('Please enter the Transaction ID (TID) received in the SMS/Receipt.');
      return;
    }

    if (!senderNumber.trim()) {
      setError('Please enter the sender mobile number or account holder name.');
      return;
    }

    setLoading(true);
    try {
      const res = await api.createDeposit({
        planId: selectedPlan.id,
        paymentMethod: activeMethod?.name || 'Manual Transfer',
        senderNumber,
        transactionId,
        notes,
      });
      setSuccess(res.message);
      setTransactionId('');
      setSenderNumber('');
      setNotes('');
      onDepositSubmitted();
    } catch (err: any) {
      setError(err.message || 'Failed to submit deposit request.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-12">
      {/* Header */}
      <div className="text-center space-y-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <ArrowDownCircle className="w-3.5 h-3.5" />
          <span>Manual Payment Verification</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Deposit & <span className="text-amber-400">Activate Plan</span>
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400">
          Transfer exact amount to the official ProfitNest account below and submit your Transaction ID (TID). Admin Shabahat Ali Kazmi will verify and activate your 30-day plan.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form: Plan selection + Payment Details */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-xl space-y-6">
            {/* Step 1: Select Plan */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2">
                1. Select Target Plan
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {plans.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedPlanId(p.id)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      selectedPlan.id === p.id
                        ? 'border-amber-400 bg-amber-500/10 text-white shadow-sm'
                        : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
                    }`}
                  >
                    <div className="text-[11px] font-bold text-amber-400">Plan #{p.id}</div>
                    <div className="text-sm font-extrabold text-white">Rs. {p.price.toLocaleString()}</div>
                    <div className="text-[10px] text-neutral-400">30 Days</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Selected Plan Summary Banner */}
            <div className="p-4 rounded-xl bg-neutral-950 border border-amber-500/30 flex items-center justify-between">
              <div>
                <span className="text-xs text-neutral-400 block">Required Deposit Amount</span>
                <span className="text-2xl font-black text-amber-400">
                  Rs. {selectedPlan.price.toLocaleString()}
                </span>
              </div>
              <div className="text-right text-xs">
                <span className="text-white font-bold block">{selectedPlan.name}</span>
                <span className="text-emerald-400 font-semibold">2 Videos/Day • Rs. {selectedPlan.rewardPerVideo} each</span>
              </div>
            </div>

            {/* Step 2: Choose Payment Method */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2">
                2. Choose Payment Method
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {paymentMethods.filter((m) => m.enabled).map((method) => {
                  const isSelected = selectedMethodId === method.id;
                  return (
                    <button
                      key={method.id}
                      type="button"
                      onClick={() => setSelectedMethodId(method.id)}
                      className={`p-3 rounded-xl border text-left transition-all flex items-center gap-3 ${
                        isSelected
                          ? 'border-amber-400 bg-amber-500/15 text-white'
                          : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      <div className="p-2 rounded-lg bg-neutral-900 text-amber-400">
                        {method.id === 'bank' ? (
                          <Building className="w-4 h-4" />
                        ) : (
                          <Smartphone className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">{method.name}</div>
                        <div className="text-[10px] text-neutral-400">{method.accountTitle}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Selected Account Info Box */}
            {activeMethod && (
              <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                    Official Payment Account
                  </span>
                  <span className="text-[11px] text-neutral-400">Administrator Configured</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-800">
                    <span className="text-neutral-500 block text-[10px] uppercase">Account Title</span>
                    <span className="font-bold text-white text-sm">{activeMethod.accountTitle}</span>
                  </div>

                  <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 flex items-center justify-between">
                    <div>
                      <span className="text-neutral-500 block text-[10px] uppercase">
                        {activeMethod.bankName ? 'Account / IBAN' : 'Account Number'}
                      </span>
                      <span className="font-mono font-bold text-amber-400 text-sm">
                        {activeMethod.accountNumber}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(activeMethod.accountNumber, 'acc')}
                      className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors"
                      title="Copy Number"
                    >
                      {copiedId === 'acc' ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {activeMethod.bankName && (
                  <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs">
                    <span className="text-neutral-500 block text-[10px] uppercase">Bank Name</span>
                    <span className="font-bold text-white">{activeMethod.bankName}</span>
                  </div>
                )}

                <div className="text-[11px] text-neutral-400 italic">
                  Note: {activeMethod.instructions}
                </div>
              </div>
            )}

            {/* Step 3: Submission Form */}
            <form onSubmit={handleSubmit} className="space-y-4 pt-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-400">
                3. Submit Payment Proof
              </label>

              {error && (
                <div className="p-3 rounded-xl bg-red-950/60 border border-red-800 text-red-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{error}</span>
                </div>
              )}

              {success && (
                <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{success}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Sender Mobile Number / Account Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 03001234567 or Sender Full Name"
                  value={senderNumber}
                  onChange={(e) => setSenderNumber(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Transaction ID (TID / Trx ID)
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 12948019482 or TR-49204"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none font-mono"
                />
                <span className="text-[10px] text-neutral-500 block mt-1">
                  Enter the exact transaction reference code found in the payment SMS or screenshot.
                </span>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Additional Notes (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Any details you want to add for the administrator..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-extrabold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-300 hover:to-yellow-400 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <ArrowDownCircle className="w-5 h-5" />
                {loading ? 'Submitting Request...' : `Submit Deposit Request for Rs. ${selectedPlan.price.toLocaleString()}`}
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Instructions & Deposit History */}
        <div className="lg:col-span-5 space-y-6">
          {/* Instructions Card */}
          <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              Deposit Instructions
            </h3>
            <ol className="space-y-3 text-xs text-neutral-300 list-decimal list-inside leading-relaxed">
              <li>
                <span className="font-semibold text-white">Select a Plan:</span> Pick from the 12 verified plans starting from Rs. 290.
              </li>
              <li>
                <span className="font-semibold text-white">Transfer Funds:</span> Send exact plan fee to official account (Title: Shaheena bukhari) via Easypaisa, JazzCash, or Meezan Bank.
              </li>
              <li>
                <span className="font-semibold text-white">Copy TID:</span> Note the Transaction ID (TID) from the confirmation SMS received on your phone.
              </li>
              <li>
                <span className="font-semibold text-white">Submit Proof:</span> Fill the form on the left with your TID and sender number.
              </li>
              <li>
                <span className="font-semibold text-white">Verification:</span> Admin checks the transaction on the bank ledger. Once verified, your 30-day plan status is automatically turned Active!
              </li>
            </ol>
            <div className="p-3 rounded-xl bg-neutral-950 border border-amber-500/20 text-[11px] text-amber-400/90">
              ⚡ Verification normally takes 15–45 minutes. For immediate priority review, WhatsApp 0343 9054908.
            </div>
          </div>

          {/* User's Previous Deposit Requests */}
          <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              Your Deposit History
            </h3>

            {deposits.length === 0 ? (
              <div className="py-6 text-center text-xs text-neutral-500">
                No deposit requests submitted yet.
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                {deposits.map((dep) => (
                  <div
                    key={dep.id}
                    className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-1.5 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">
                        Rs. {dep.amount.toLocaleString()} (Plan {dep.planId})
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          dep.status === 'Approved'
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                            : dep.status === 'Pending'
                            ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                            : 'bg-red-500/15 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {dep.status}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-neutral-400 font-mono">
                      <span>TID: {dep.transactionId}</span>
                      <span>{dep.paymentMethod}</span>
                    </div>

                    <div className="text-[10px] text-neutral-500">
                      {new Date(dep.createdAt).toLocaleString()}
                    </div>

                    {dep.adminNote && (
                      <div className="text-[11px] text-amber-300/80 bg-neutral-900 p-1.5 rounded">
                        Admin Note: {dep.adminNote}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
