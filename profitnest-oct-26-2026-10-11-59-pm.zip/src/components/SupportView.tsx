import React, { useState } from 'react';
import {
  HelpCircle,
  Phone,
  MessageCircle,
  Mail,
  Send,
  CheckCircle2,
  AlertCircle,
  UserCheck,
  ShieldCheck,
  Clock,
  MessageSquare,
} from 'lucide-react';
import { User, SupportTicket, PlatformSettings } from '../types';
import { api } from '../services/api';

interface SupportViewProps {
  user: User | null;
  settings: PlatformSettings | null;
  tickets: SupportTicket[];
  onTicketSubmitted: () => void;
}

export const SupportView: React.FC<SupportViewProps> = ({
  user,
  settings,
  tickets,
  onTicketSubmitted,
}) => {
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState('Payment / Deposit');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const ownerName = settings?.ownerName || 'Shabahat Ali Kazmi';
  const ownerContact = settings?.ownerContact || '0331 5014004';
  const adminName = settings?.adminName || 'Shabahat Ali Kazmi';
  const adminContact = settings?.adminContact || '0343 9054908';

  // Format Pakistani numbers for whatsapp (923315014004)
  const formatForWhatsApp = (numStr: string) => {
    const clean = numStr.replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) {
      return '92' + clean.slice(1);
    }
    return clean;
  };

  const handleTicketSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!user) {
      setError('Please log in to submit a direct support ticket.');
      return;
    }

    setLoading(true);
    try {
      const res = await api.createSupportTicket({
        subject,
        category,
        message,
      });
      setSuccess(res.message);
      setSubject('');
      setMessage('');
      onTicketSubmitted();
    } catch (err: any) {
      setError(err.message || 'Failed to submit support request.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-12">
      {/* Header */}
      <div className="text-center space-y-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <HelpCircle className="w-3.5 h-3.5" />
          <span>Official Customer Helpdesk</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Customer <span className="text-amber-400">Support</span>
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400">
          Direct contact channels with Shabahat Ali Kazmi. We are available for deposit verification, withdrawal inquiries, and technical guidance.
        </p>
      </div>

      {/* Official Verified Contact Cards (Requirement 14) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Owner Contact Card */}
        <div className="rounded-2xl bg-neutral-900 border border-amber-500/30 p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-amber-400/10 text-amber-400 border border-amber-400/20">
                <UserCheck className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] text-amber-400 uppercase font-extrabold tracking-wider block">
                  Website Owner
                </span>
                <h3 className="text-lg font-black text-white">{ownerName}</h3>
              </div>
            </div>
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">
              Verified
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 text-xs space-y-1">
            <span className="text-neutral-500 block text-[10px] uppercase">Direct Phone Line</span>
            <span className="font-mono font-bold text-white text-base">{ownerContact}</span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <a
              href={`tel:${ownerContact.replace(/\s+/g, '')}`}
              className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs flex items-center justify-center gap-2 border border-neutral-700 transition-colors"
            >
              <Phone className="w-4 h-4 text-amber-400" />
              Call Owner
            </a>
            <a
              href={`https://wa.me/${formatForWhatsApp(ownerContact)}`}
              target="_blank"
              rel="noreferrer"
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp
            </a>
          </div>
        </div>

        {/* Administrator Contact Card */}
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] text-blue-400 uppercase font-extrabold tracking-wider block">
                  Platform Administrator
                </span>
                <h3 className="text-lg font-black text-white">{adminName}</h3>
              </div>
            </div>
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-blue-500/15 text-blue-300 border border-blue-500/30">
              Admin & Payments
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 text-xs space-y-1">
            <span className="text-neutral-500 block text-[10px] uppercase">Admin Direct Contact</span>
            <span className="font-mono font-bold text-white text-base">{adminContact}</span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <a
              href={`tel:${adminContact.replace(/\s+/g, '')}`}
              className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs flex items-center justify-center gap-2 border border-neutral-700 transition-colors"
            >
              <Phone className="w-4 h-4 text-blue-400" />
              Call Admin
            </a>
            <a
              href={`https://wa.me/${formatForWhatsApp(adminContact)}`}
              target="_blank"
              rel="noreferrer"
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp Admin
            </a>
          </div>
        </div>
      </div>

      {/* Support Ticket Submission + Ticket List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Ticket Form */}
        <div className="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Send className="w-4 h-4 text-amber-400" />
            Submit a Support Request
          </h3>
          <p className="text-xs text-neutral-400">
            Send an inquiry directly to the administrator dashboard. You will receive a response within a few hours.
          </p>

          {error && (
            <div className="p-3 rounded-xl bg-red-950/60 border border-red-800 text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{success}</span>
            </div>
          )}

          <form onSubmit={handleTicketSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
              >
                <option value="Deposit / TID Verification">Deposit / TID Verification</option>
                <option value="Withdrawal Processing">Withdrawal Processing</option>
                <option value="Plan Activation Inquiry">Plan Activation Inquiry</option>
                <option value="Video Task Reward Issue">Video Task Reward Issue</option>
                <option value="Referral Commission">Referral Commission</option>
                <option value="General Question">General Question</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Subject</label>
              <input
                type="text"
                required
                placeholder="Brief summary of your inquiry"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Message</label>
              <textarea
                required
                rows={4}
                placeholder="Describe your issue with transaction IDs, amounts, or details..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-400 rounded-xl px-4 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading || !user}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-bold text-xs sm:text-sm shadow-md shadow-amber-500/20 hover:from-amber-300 hover:to-yellow-400 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              {loading ? 'Submitting...' : 'Send Support Request'}
            </button>

            {!user && (
              <p className="text-[11px] text-center text-amber-400">
                Please log in to your account to submit and view support tickets.
              </p>
            )}
          </form>
        </div>

        {/* User's Previous Tickets */}
        <div className="lg:col-span-5 bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-amber-400" />
            Your Support Inquiries
          </h3>

          {tickets.length === 0 ? (
            <div className="py-12 text-center text-xs text-neutral-500">
              No support tickets submitted yet.
            </div>
          ) : (
            <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
              {tickets.map((t) => (
                <div
                  key={t.id}
                  className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 text-xs space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">{t.subject}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        t.status === 'Resolved'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : t.status === 'In Progress'
                          ? 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
                          : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {t.status}
                    </span>
                  </div>

                  <p className="text-neutral-400 text-[11px]">{t.message}</p>

                  <div className="text-[10px] text-neutral-500 font-mono flex items-center justify-between">
                    <span>Category: {t.category}</span>
                    <span>{new Date(t.createdAt).toLocaleDateString()}</span>
                  </div>

                  {t.adminReply && (
                    <div className="mt-2 p-2 rounded-lg bg-neutral-900 border border-amber-500/20 text-amber-300 text-[11px]">
                      <span className="font-bold text-amber-400 block mb-0.5">
                        Admin Shabahat Ali Kazmi replied:
                      </span>
                      {t.adminReply}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
