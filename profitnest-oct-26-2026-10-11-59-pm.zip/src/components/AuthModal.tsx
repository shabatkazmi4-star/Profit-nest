import React, { useState } from 'react';
import { Lock, Phone, User as UserIcon, Tag, AlertCircle, CheckCircle2, Coins, ArrowRight, ShieldCheck } from 'lucide-react';
import { api } from '../services/api';
import { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
  initialTab?: 'login' | 'register';
  defaultReferralCode?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialTab = 'login',
  defaultReferralCode = '',
}) => {
  const [tab, setTab] = useState<'login' | 'register'>(initialTab);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [forgotModalOpen, setForgotModalOpen] = useState(false);
  const [forgotMobile, setForgotMobile] = useState('');
  const [forgotInfo, setForgotInfo] = useState<string | null>(null);

  // Form states
  const [fullName, setFullName] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [referralCode, setReferralCode] = useState(defaultReferralCode);

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await api.login({ mobile, password });
      onSuccess(res.user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.register({
        fullName,
        mobile,
        password,
        confirmPassword,
        referralCode,
      });
      setSuccessMsg(res.message);
      setTimeout(() => {
        onSuccess(res.user);
        onClose();
      }, 1000);
    } catch (err: any) {
      setError(err.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.forgotPassword(forgotMobile);
      setForgotInfo(res.message);
    } catch (err: any) {
      setForgotInfo('Please contact Administrator Shabahat Ali Kazmi at 0343 9054908 for assistance.');
    }
  };

  const prefillAdmin = () => {
    setTab('login');
    setMobile('03439054908');
    setPassword('admin123');
    setError(null);
  };

  const prefillDemoMember = () => {
    setTab('login');
    setMobile('03001234567');
    setPassword('user123');
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-md bg-neutral-950 border border-amber-500/30 rounded-2xl p-6 shadow-2xl text-white my-8">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-600 text-neutral-950 shadow-lg shadow-amber-500/20 mb-3">
            <Coins className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight text-white">
            Profit<span className="text-amber-400">Nest</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">Watch • Earn • Rewards</p>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 p-1 bg-neutral-900 border border-neutral-800 rounded-xl mb-6">
          <button
            type="button"
            onClick={() => {
              setTab('login');
              setError(null);
            }}
            className={`py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all ${
              tab === 'login'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Login
          </button>
          <button
            type="button"
            onClick={() => {
              setTab('register');
              setError(null);
            }}
            className={`py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all ${
              tab === 'register'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Create Account
          </button>
        </div>

        {/* Alerts */}
        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-950/50 border border-red-800/60 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 rounded-lg bg-emerald-950/50 border border-emerald-800/60 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Form Body */}
        {tab === 'login' ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Mobile Number
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute left-3 top-3 text-neutral-500" />
                <input
                  type="tel"
                  required
                  placeholder="e.g. 03439054908"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-400 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-neutral-300">Password</label>
                <button
                  type="button"
                  onClick={() => setForgotModalOpen(true)}
                  className="text-xs text-amber-400 hover:underline"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-3 text-neutral-500" />
                <input
                  type="password"
                  required
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-400 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-bold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-300 hover:to-yellow-400 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? 'Authenticating...' : 'Login to Dashboard'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegister} className="space-y-3.5">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Full Name</label>
              <div className="relative">
                <UserIcon className="w-4 h-4 absolute left-3 top-3 text-neutral-500" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Shabahat Ali"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-400 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Mobile Number</label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute left-3 top-3 text-neutral-500" />
                <input
                  type="tel"
                  required
                  placeholder="e.g. 03315014004"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-400 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Password</label>
                <input
                  type="password"
                  required
                  placeholder="Min 6 chars"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-400 rounded-xl px-3 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Confirm</label>
                <input
                  type="password"
                  required
                  placeholder="Re-enter"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-400 rounded-xl px-3 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Referral Code (Optional)
              </label>
              <div className="relative">
                <Tag className="w-4 h-4 absolute left-3 top-3 text-neutral-500" />
                <input
                  type="text"
                  placeholder="e.g. PN-789012"
                  value={referralCode}
                  onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                  className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-400 rounded-xl pl-10 pr-4 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none uppercase"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-bold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-300 hover:to-yellow-400 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? 'Creating Account...' : 'Create Account'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* Quick Demo Credentials Assistant */}
        <div className="mt-6 pt-5 border-t border-neutral-800/80">
          <div className="text-[11px] text-neutral-400 font-medium mb-2.5 text-center flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Fast Sign-in Presets for Testing</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={prefillAdmin}
              className="px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-amber-500/30 text-amber-300 text-[11px] font-semibold hover:bg-neutral-800 hover:border-amber-400 transition-all text-left"
            >
              <span className="block font-bold">Admin Shabahat</span>
              <span className="text-[10px] text-neutral-400">03439054908 / admin123</span>
            </button>
            <button
              type="button"
              onClick={prefillDemoMember}
              className="px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300 text-[11px] font-semibold hover:bg-neutral-800 hover:border-neutral-700 transition-all text-left"
            >
              <span className="block font-bold">Member Demo</span>
              <span className="text-[10px] text-neutral-400">03001234567 / user123</span>
            </button>
          </div>
        </div>

        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="mt-4 w-full py-2 text-xs text-neutral-500 hover:text-neutral-300 transition-colors"
        >
          Cancel & Close
        </button>
      </div>

      {/* Forgot Password Modal */}
      {forgotModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90">
          <div className="bg-neutral-900 border border-amber-500/40 rounded-2xl p-6 max-w-sm w-full text-white">
            <h3 className="text-base font-bold text-amber-400 mb-2">Reset Password</h3>
            <p className="text-xs text-neutral-300 mb-4">
              Enter your registered mobile number to see administrator verification instructions.
            </p>
            <form onSubmit={handleForgotPassword} className="space-y-3">
              <input
                type="tel"
                required
                placeholder="Your mobile number"
                value={forgotMobile}
                onChange={(e) => setForgotMobile(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-white"
              />
              <button
                type="submit"
                className="w-full py-2 rounded-xl bg-amber-400 text-neutral-950 font-bold text-xs"
              >
                Request Assistance
              </button>
            </form>

            {forgotInfo && (
              <div className="mt-3 p-3 bg-neutral-950 rounded-lg text-xs text-amber-300 border border-amber-500/30">
                {forgotInfo}
              </div>
            )}

            <button
              onClick={() => {
                setForgotModalOpen(false);
                setForgotInfo(null);
              }}
              className="mt-4 text-xs text-neutral-400 hover:text-white block w-full text-center"
            >
              Back to Login
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
