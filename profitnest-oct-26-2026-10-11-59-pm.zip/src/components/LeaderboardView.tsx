import React from 'react';
import { Trophy, Award, Medal, ShieldCheck, Sparkles, Coins } from 'lucide-react';

interface LeaderboardViewProps {
  leaderboard: { name: string; maskedMobile: string; totalRewards: number; plan: string }[];
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({ leaderboard }) => {
  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-12">
      {/* Header */}
      <div className="text-center space-y-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <Trophy className="w-3.5 h-3.5" />
          <span>Real Verified Earners</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          ProfitNest <span className="text-amber-400">Leaderboard</span>
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400">
          Rankings based strictly on verified video rewards and genuine referral earnings. Zero simulated or fabricated figures.
        </p>
      </div>

      {/* Top 3 Podium if at least 1 earner */}
      {leaderboard.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto pt-4">
          {/* Rank 2 */}
          {leaderboard[1] && (
            <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 flex flex-col items-center text-center shadow-lg order-2 md:order-1 relative">
              <div className="w-12 h-12 rounded-full bg-neutral-800 text-neutral-300 flex items-center justify-center font-bold text-lg mb-3 border border-neutral-700">
                2
              </div>
              <Medal className="w-6 h-6 text-neutral-400 mb-1" />
              <h3 className="font-bold text-white text-base">{leaderboard[1].name}</h3>
              <span className="text-[11px] font-mono text-neutral-500">{leaderboard[1].maskedMobile}</span>
              <span className="text-xs font-semibold text-amber-400/90 mt-1">{leaderboard[1].plan}</span>
              <div className="mt-3 text-lg font-black text-white">
                Rs. {leaderboard[1].totalRewards.toLocaleString()}
              </div>
              <span className="text-[10px] text-neutral-500 uppercase tracking-wider">Verified Rewards</span>
            </div>
          )}

          {/* Rank 1 */}
          {leaderboard[0] && (
            <div className="rounded-2xl bg-gradient-to-b from-amber-950/40 via-neutral-900 to-neutral-900 border-2 border-amber-400 p-6 flex flex-col items-center text-center shadow-xl shadow-amber-500/10 order-1 md:order-2 md:-mt-4 relative">
              <div className="absolute -top-3 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 text-[10px] font-extrabold uppercase tracking-widest shadow-md">
                Top Earner
              </div>
              <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-500 text-neutral-950 flex items-center justify-center font-black text-xl mb-3 shadow-lg shadow-amber-500/20">
                1
              </div>
              <Trophy className="w-7 h-7 text-amber-400 mb-1" />
              <h3 className="font-extrabold text-white text-lg">{leaderboard[0].name}</h3>
              <span className="text-xs font-mono text-neutral-400">{leaderboard[0].maskedMobile}</span>
              <span className="text-xs font-bold text-amber-400 mt-1">{leaderboard[0].plan}</span>
              <div className="mt-3 text-2xl font-black text-amber-400">
                Rs. {leaderboard[0].totalRewards.toLocaleString()}
              </div>
              <span className="text-[10px] text-neutral-400 uppercase tracking-wider font-semibold">Total Verified Payouts</span>
            </div>
          )}

          {/* Rank 3 */}
          {leaderboard[2] && (
            <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 flex flex-col items-center text-center shadow-lg order-3 relative">
              <div className="w-12 h-12 rounded-full bg-neutral-800 text-amber-700 flex items-center justify-center font-bold text-lg mb-3 border border-neutral-700">
                3
              </div>
              <Award className="w-6 h-6 text-amber-700 mb-1" />
              <h3 className="font-bold text-white text-base">{leaderboard[2].name}</h3>
              <span className="text-[11px] font-mono text-neutral-500">{leaderboard[2].maskedMobile}</span>
              <span className="text-xs font-semibold text-amber-400/90 mt-1">{leaderboard[2].plan}</span>
              <div className="mt-3 text-lg font-black text-white">
                Rs. {leaderboard[2].totalRewards.toLocaleString()}
              </div>
              <span className="text-[10px] text-neutral-500 uppercase tracking-wider">Verified Rewards</span>
            </div>
          )}
        </div>
      )}

      {/* Complete Real Rankings Table */}
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 overflow-hidden shadow-xl max-w-4xl mx-auto">
        <div className="p-4 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
            <Coins className="w-4 h-4" />
            Verified Earnings Standing
          </span>
          <span className="text-[11px] text-neutral-500 font-medium">Real Platform Records</span>
        </div>

        {leaderboard.length === 0 ? (
          <div className="py-12 text-center text-xs text-neutral-500">
            No verified rewards awarded yet. Complete video tasks to be the first on the leaderboard!
          </div>
        ) : (
          <div className="divide-y divide-neutral-800">
            {leaderboard.map((item, index) => (
              <div
                key={index}
                className="px-6 py-4 flex items-center justify-between hover:bg-neutral-800/40 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <span
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                      index === 0
                        ? 'bg-amber-400 text-neutral-950'
                        : index === 1
                        ? 'bg-neutral-300 text-neutral-950'
                        : index === 2
                        ? 'bg-amber-700 text-white'
                        : 'bg-neutral-800 text-neutral-400'
                    }`}
                  >
                    #{index + 1}
                  </span>
                  <div>
                    <div className="font-bold text-white text-sm">{item.name}</div>
                    <div className="text-[11px] text-neutral-400 font-mono">
                      {item.maskedMobile} • <span className="text-amber-400/90">{item.plan}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-black text-amber-400 font-mono text-sm sm:text-base">
                    Rs. {item.totalRewards.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-neutral-500 uppercase">Verified</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="max-w-4xl mx-auto p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-400 text-xs flex items-start gap-2.5">
        <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <span>
          Compliance Notice: ProfitNest publishes real earnings directly from verified database ledger transactions. We do not generate mock names, bots, or artificial leaderboard entries.
        </span>
      </div>
    </div>
  );
};
