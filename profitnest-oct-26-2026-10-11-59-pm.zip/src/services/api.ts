import {
  User,
  Plan,
  VideoTask,
  Deposit,
  Withdrawal,
  Transaction,
  SupportTicket,
  PlatformSettings,
  Announcement,
  AdminLog,
} from '../types';

const TOKEN_KEY = 'profitnest_auth_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string | null) {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

async function fetchWithAuth(url: string, options: RequestInit = {}) {
  const token = getStoredToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (token) {
    (headers as Record<string, string>)['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || data.message || `Request failed with status ${response.status}`);
  }

  return data;
}

export const api = {
  // Public & Settings
  getSettings: async (): Promise<{ settings: PlatformSettings; announcements: Announcement[] }> => {
    return fetchWithAuth('/api/settings');
  },

  // Auth
  register: async (payload: {
    fullName: string;
    mobile: string;
    password: string;
    confirmPassword: string;
    referralCode?: string;
  }): Promise<{ token: string; user: User; message: string }> => {
    const data = await fetchWithAuth('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    setStoredToken(data.token);
    return data;
  },

  login: async (payload: {
    mobile: string;
    password: string;
  }): Promise<{ token: string; user: User; message: string }> => {
    const data = await fetchWithAuth('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    setStoredToken(data.token);
    return data;
  },

  getMe: async (): Promise<{ user: User; plan: Plan | null }> => {
    return fetchWithAuth('/api/auth/me');
  },

  changePassword: async (payload: {
    oldPassword: string;
    newPassword: string;
    confirmNewPassword: string;
  }): Promise<{ success: boolean; message: string }> => {
    return fetchWithAuth('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  forgotPassword: async (mobile: string): Promise<{ message: string; adminContact: string; ownerContact: string }> => {
    return fetchWithAuth('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ mobile }),
    });
  },

  logout: () => {
    setStoredToken(null);
  },

  // Dashboard
  getDashboard: async (): Promise<{
    user: User;
    activePlan: Plan | null;
    isPlanActive: boolean;
    remainingDays: number;
    completedToday: number;
    maxDailyVideos: number;
    recentTransactions: Transaction[];
  }> => {
    return fetchWithAuth('/api/dashboard');
  },

  // Plans
  getPlans: async (): Promise<{ plans: Plan[] }> => {
    return fetchWithAuth('/api/plans');
  },

  // Videos
  getVideos: async (): Promise<{
    videos: VideoTask[];
    activePlan: { name: string; price: number; rewardPerVideo: number } | null;
    completedTodayCount: number;
    maxDailyVideos: number;
    requiresPlan: boolean;
  }> => {
    return fetchWithAuth('/api/videos');
  },

  claimVideoReward: async (payload: {
    videoId: string;
    watchDurationSeconds: number;
  }): Promise<{ success: boolean; rewardAmount: number; newBalance: number; message: string }> => {
    return fetchWithAuth('/api/videos/claim', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // Deposits
  getDeposits: async (): Promise<{ deposits: Deposit[] }> => {
    return fetchWithAuth('/api/deposits');
  },

  createDeposit: async (payload: {
    planId: number;
    paymentMethod: string;
    senderNumber: string;
    transactionId: string;
    notes?: string;
  }): Promise<{ success: boolean; deposit: Deposit; message: string }> => {
    return fetchWithAuth('/api/deposits', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // Withdrawals
  getWithdrawals: async (): Promise<{ withdrawals: Withdrawal[]; availableBalance: number }> => {
    return fetchWithAuth('/api/withdrawals');
  },

  createWithdrawal: async (payload: {
    amount: number;
    accountHolder: string;
    paymentMethod: string;
    accountNumber: string;
  }): Promise<{ success: boolean; withdrawal: Withdrawal; remainingBalance: number; message: string }> => {
    return fetchWithAuth('/api/withdrawals', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // Transactions
  getTransactions: async (): Promise<{ transactions: Transaction[] }> => {
    return fetchWithAuth('/api/transactions');
  },

  // Referrals
  getReferrals: async (): Promise<{
    referralCode: string;
    totalInvited: number;
    referredUsers: { fullName: string; mobile: string; createdAt: string; activePlan: string }[];
    totalReferralRewards: number;
    commissionRate: number;
  }> => {
    return fetchWithAuth('/api/referrals');
  },

  // Leaderboard
  getLeaderboard: async (): Promise<{
    leaderboard: { name: string; maskedMobile: string; totalRewards: number; plan: string }[];
  }> => {
    return fetchWithAuth('/api/leaderboard');
  },

  // Support
  getSupportTickets: async (): Promise<{ tickets: SupportTicket[] }> => {
    return fetchWithAuth('/api/support');
  },

  createSupportTicket: async (payload: {
    subject: string;
    category: string;
    message: string;
  }): Promise<{ success: boolean; ticket: SupportTicket; message: string }> => {
    return fetchWithAuth('/api/support', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // Admin APIs
  getAdminOverview: async (): Promise<{
    totalUsers: number;
    activePlansCount: number;
    pendingDeposits: number;
    pendingWithdrawals: number;
    totalPaidOut: number;
    totalDeposited: number;
  }> => {
    return fetchWithAuth('/api/admin/overview');
  },

  getAdminUsers: async (): Promise<{ users: User[] }> => {
    return fetchWithAuth('/api/admin/users');
  },

  getAdminDeposits: async (): Promise<{ deposits: Deposit[] }> => {
    return fetchWithAuth('/api/admin/deposits');
  },

  verifyAdminDeposit: async (
    id: string,
    action: 'approve' | 'reject',
    adminNote?: string
  ): Promise<{ success: boolean; deposit: Deposit; message: string }> => {
    return fetchWithAuth(`/api/admin/deposits/${id}/verify`, {
      method: 'POST',
      body: JSON.stringify({ action, adminNote }),
    });
  },

  getAdminWithdrawals: async (): Promise<{ withdrawals: Withdrawal[] }> => {
    return fetchWithAuth('/api/admin/withdrawals');
  },

  updateAdminWithdrawal: async (
    id: string,
    status: 'Processing' | 'Paid' | 'Rejected',
    adminReference?: string
  ): Promise<{ success: boolean; withdrawal: Withdrawal; message: string }> => {
    return fetchWithAuth(`/api/admin/withdrawals/${id}/update`, {
      method: 'POST',
      body: JSON.stringify({ status, adminReference }),
    });
  },

  getAdminSupport: async (): Promise<{ tickets: SupportTicket[] }> => {
    return fetchWithAuth('/api/admin/support');
  },

  replyAdminSupport: async (
    id: string,
    adminReply: string,
    status?: string
  ): Promise<{ success: boolean; ticket: SupportTicket }> => {
    return fetchWithAuth(`/api/admin/support/${id}/reply`, {
      method: 'POST',
      body: JSON.stringify({ adminReply, status }),
    });
  },

  postAdminAnnouncement: async (
    title: string,
    message: string
  ): Promise<{ success: boolean; announcement: Announcement }> => {
    return fetchWithAuth('/api/admin/announcements', {
      method: 'POST',
      body: JSON.stringify({ title, message }),
    });
  },

  updateAdminSettings: async (payload: Partial<PlatformSettings>): Promise<{ success: boolean; settings: PlatformSettings }> => {
    return fetchWithAuth('/api/admin/settings', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getAdminLogs: async (): Promise<{ logs: AdminLog[] }> => {
    return fetchWithAuth('/api/admin/logs');
  },
};
