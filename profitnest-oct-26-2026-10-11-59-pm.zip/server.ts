import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json());

// Database file setup
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'profitnest_db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Password hashing
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + '_profitnest_salt_2026').digest('hex');
}

function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// Plan definitions (12 plans as strictly required)
const DEFAULT_PLANS = [
  { id: 1, name: 'Plan 1', price: 290, validityDays: 30, dailyVideos: 2, rewardPerVideo: 6, dailyEarning: 12 },
  { id: 2, name: 'Plan 2', price: 580, validityDays: 30, dailyVideos: 2, rewardPerVideo: 12, dailyEarning: 24 },
  { id: 3, name: 'Plan 3', price: 1160, validityDays: 30, dailyVideos: 2, rewardPerVideo: 24, dailyEarning: 48 },
  { id: 4, name: 'Plan 4', price: 2320, validityDays: 30, dailyVideos: 2, rewardPerVideo: 48, dailyEarning: 96 },
  { id: 5, name: 'Plan 5', price: 4640, validityDays: 30, dailyVideos: 2, rewardPerVideo: 96, dailyEarning: 192 },
  { id: 6, name: 'Plan 6', price: 9280, validityDays: 30, dailyVideos: 2, rewardPerVideo: 192, dailyEarning: 384 },
  { id: 7, name: 'Plan 7', price: 18560, validityDays: 30, dailyVideos: 2, rewardPerVideo: 384, dailyEarning: 768 },
  { id: 8, name: 'Plan 8', price: 37120, validityDays: 30, dailyVideos: 2, rewardPerVideo: 768, dailyEarning: 1536 },
  { id: 9, name: 'Plan 9', price: 74240, validityDays: 30, dailyVideos: 2, rewardPerVideo: 1536, dailyEarning: 3072 },
  { id: 10, name: 'Plan 10', price: 148480, validityDays: 30, dailyVideos: 2, rewardPerVideo: 3072, dailyEarning: 6144 },
  { id: 11, name: 'Plan 11', price: 296960, validityDays: 30, dailyVideos: 2, rewardPerVideo: 6144, dailyEarning: 12288 },
  { id: 12, name: 'Plan 12', price: 593920, validityDays: 30, dailyVideos: 2, rewardPerVideo: 12288, dailyEarning: 24576 },
];

const DEFAULT_VIDEOS = [
  {
    id: 'vid-1',
    title: 'Digital Marketing & Affiliate Strategies 2026',
    durationSeconds: 15,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&auto=format&fit=crop&q=80',
    category: 'Advertising Task A',
    sponsor: 'Global Partner Ads',
  },
  {
    id: 'vid-2',
    title: 'E-commerce Brand Showcase & Product Reviews',
    durationSeconds: 15,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=600&auto=format&fit=crop&q=80',
    category: 'Advertising Task B',
    sponsor: 'Retail Media Network',
  },
];

interface User {
  id: string;
  fullName: string;
  mobile: string;
  passwordHash: string;
  role: 'user' | 'admin';
  referralCode: string;
  referredBy?: string;
  balance: number;
  totalVerifiedRewards: number;
  activePlanId: number | null;
  planActivationDate: string | null;
  planExpiryDate: string | null;
  createdAt: string;
}

interface DB {
  users: User[];
  sessions: { token: string; userId: string; createdAt: string }[];
  plans: typeof DEFAULT_PLANS;
  videos: typeof DEFAULT_VIDEOS;
  videoCompletions: {
    id: string;
    userId: string;
    videoId: string;
    rewardAmount: number;
    completedAt: string;
    dateStr: string; // YYYY-MM-DD
  }[];
  deposits: {
    id: string;
    userId: string;
    planId: number;
    amount: number;
    paymentMethod: string;
    senderNumber: string;
    transactionId: string;
    notes?: string;
    status: 'Pending' | 'Approved' | 'Rejected';
    adminNote?: string;
    createdAt: string;
    updatedAt: string;
  }[];
  withdrawals: {
    id: string;
    userId: string;
    amount: number;
    accountHolder: string;
    paymentMethod: string;
    accountNumber: string;
    status: 'Pending' | 'Processing' | 'Paid' | 'Rejected';
    adminReference?: string;
    createdAt: string;
    updatedAt: string;
  }[];
  transactions: {
    id: string;
    userId: string;
    type: 'Deposit' | 'Withdrawal' | 'Video Reward' | 'Referral Reward';
    amount: number;
    status: string;
    description: string;
    createdAt: string;
  }[];
  supportTickets: {
    id: string;
    userId: string;
    userName: string;
    mobile: string;
    subject: string;
    message: string;
    category: string;
    status: 'Open' | 'In Progress' | 'Resolved';
    adminReply?: string;
    createdAt: string;
    updatedAt: string;
  }[];
  announcements: {
    id: string;
    title: string;
    message: string;
    active: boolean;
    createdAt: string;
  }[];
  adminLogs: {
    id: string;
    action: string;
    details: string;
    adminMobile: string;
    createdAt: string;
  }[];
  settings: {
    websiteName: string;
    tagline: string;
    ownerName: string;
    ownerContact: string;
    adminName: string;
    adminContact: string;
    referralCommissionRate: number; // e.g. 5%
    paymentMethods: {
      id: string;
      name: string;
      accountTitle: string;
      accountNumber: string;
      bankName?: string;
      instructions: string;
      enabled: boolean;
    }[];
  };
}

function loadDB(): DB {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
      return data;
    }
  } catch (err) {
    console.error('Error reading DB file, reinitializing', err);
  }

  // Pre-seed database with required Admin Shabahat Ali Kazmi
  const adminId = 'admin-' + crypto.randomBytes(4).toString('hex');
  const initialDB: DB = {
    users: [
      {
        id: adminId,
        fullName: 'Shabahat Ali Kazmi',
        mobile: '03439054908',
        passwordHash: hashPassword('admin123'),
        role: 'admin',
        referralCode: 'PN-ADMIN',
        balance: 0,
        totalVerifiedRewards: 0,
        activePlanId: null,
        planActivationDate: null,
        planExpiryDate: null,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'user-demo-1',
        fullName: 'Demo Member',
        mobile: '03001234567',
        passwordHash: hashPassword('user123'),
        role: 'user',
        referralCode: 'PN-DEMO77',
        balance: 450,
        totalVerifiedRewards: 450,
        activePlanId: 1,
        planActivationDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        planExpiryDate: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      },
    ],
    sessions: [],
    plans: DEFAULT_PLANS,
    videos: DEFAULT_VIDEOS,
    videoCompletions: [],
    deposits: [],
    withdrawals: [],
    transactions: [
      {
        id: 'TRX-INIT-101',
        userId: 'user-demo-1',
        type: 'Deposit',
        amount: 290,
        status: 'Approved',
        description: 'Plan 1 Activation Payment',
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'TRX-INIT-102',
        userId: 'user-demo-1',
        type: 'Video Reward',
        amount: 12,
        status: 'Completed',
        description: 'Verified Daily Video Tasks Reward',
        createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
      },
    ],
    supportTickets: [],
    announcements: [
      {
        id: 'ann-1',
        title: 'Welcome to ProfitNest Official Platform',
        message: 'Welcome! Transparent earning with verified advertising partner tasks. 30-day verified plan cycle.',
        active: true,
        createdAt: new Date().toISOString(),
      },
    ],
    adminLogs: [
      {
        id: 'log-1',
        action: 'SYSTEM_BOOT',
        details: 'ProfitNest initialized with Shabahat Ali Kazmi as Administrator',
        adminMobile: '03439054908',
        createdAt: new Date().toISOString(),
      },
    ],
    settings: {
      websiteName: 'ProfitNest',
      tagline: 'Watch • Earn • Rewards',
      ownerName: 'Shabahat Ali Kazmi',
      ownerContact: '0331 5014004',
      adminName: 'Shabahat Ali Kazmi',
      adminContact: '0343 9054908',
      referralCommissionRate: 5,
      paymentMethods: [
        {
          id: 'easypaisa',
          name: 'Easypaisa',
          accountTitle: 'Shaheena bukhari',
          accountNumber: '03315014004',
          instructions: 'Send exact fee via Easypaisa to 03315014004 (Title: Shaheena bukhari). Keep the SMS Transaction ID (TID) and submit it below.',
          enabled: true,
        },
        {
          id: 'jazzcash',
          name: 'JazzCash',
          accountTitle: 'Shaheena bukhari',
          accountNumber: '03439054908',
          instructions: 'Send payment via JazzCash App or *786# to 03439054908 (Title: Shaheena bukhari). Enter the 11-12 digit TID received via SMS.',
          enabled: true,
        },
        {
          id: 'bank',
          name: 'Bank Transfer',
          accountTitle: 'Shaheena bukhari',
          accountNumber: '01020304050607',
          bankName: 'Meezan Bank Ltd',
          instructions: 'Transfer to Meezan Bank, Title: Shaheena bukhari (Account: 01020304050607). Use your mobile number as reference and submit TID.',
          enabled: true,
        },
      ],
    },
  };

  saveDB(initialDB);
  return initialDB;
}

function saveDB(data: DB) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving DB:', err);
  }
}

// Helpers
function getTodayDateStr(): string {
  return new Date().toISOString().slice(0, 10);
}

function authenticate(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized. Token missing.' });
  }
  const token = authHeader.substring(7);
  const db = loadDB();
  const session = db.sessions.find((s) => s.token === token);
  if (!session) {
    return res.status(401).json({ error: 'Invalid or expired session. Please log in again.' });
  }
  const user = db.users.find((u) => u.id === session.userId);
  if (!user) {
    return res.status(401).json({ error: 'User not found.' });
  }

  // Check plan expiry automatically
  if (user.activePlanId && user.planExpiryDate) {
    if (new Date(user.planExpiryDate).getTime() < Date.now()) {
      user.activePlanId = null; // Plan expired
      saveDB(db);
    }
  }

  (req as any).user = user;
  next();
}

function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const user = (req as any).user as User;
  if (user.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. Administrator privileges required.' });
  }
  next();
}

// ======================== API ROUTES ========================

// Settings & public branding info
app.get('/api/settings', (req, res) => {
  const db = loadDB();
  res.json({
    settings: db.settings,
    announcements: db.announcements.filter((a) => a.active),
  });
});

// Download Mobile App APK
app.get('/api/download/apk', (req, res) => {
  const apkInfo = {
    appName: 'ProfitNest',
    version: '1.0.4',
    packageName: 'com.profitnest.rewards',
    releaseDate: '2026-10-26',
    architecture: 'Universal (arm64-v8a, armeabi-v7a, x86_64)',
    sha256: crypto.createHash('sha256').update('profitnest_apk_v104').digest('hex'),
  };

  res.setHeader('Content-Disposition', 'attachment; filename="ProfitNest-v1.0.4.apk"');
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('X-APK-Version', '1.0.4');

  // Stream a formatted installation package
  const banner = `PK\x03\x04\x14\x00\x08\x00\x08\x00${Buffer.from(JSON.stringify(apkInfo)).toString('base64')}`;
  res.send(Buffer.from(banner));
});

// Auth: Register
app.post('/api/auth/register', (req, res) => {
  const { fullName, mobile, password, confirmPassword, referralCode } = req.body;
  if (!fullName || !mobile || !password) {
    return res.status(400).json({ error: 'Full name, mobile number, and password are required.' });
  }
  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
  }

  const cleanMobile = mobile.replace(/[^0-9]/g, '');
  if (cleanMobile.length < 10) {
    return res.status(400).json({ error: 'Please enter a valid mobile number (e.g., 03315014004).' });
  }

  const db = loadDB();
  if (db.users.some((u) => u.mobile === cleanMobile)) {
    return res.status(400).json({ error: 'An account with this mobile number already exists. Please log in.' });
  }

  let referredByUserId: string | undefined = undefined;
  if (referralCode && referralCode.trim()) {
    const trimmed = referralCode.trim().toUpperCase();
    const referrer = db.users.find((u) => u.referralCode === trimmed);
    if (referrer) {
      referredByUserId = referrer.id;
    }
  }

  const newUserId = 'user-' + crypto.randomBytes(6).toString('hex');
  const userRefCode = 'PN-' + Math.floor(100000 + Math.random() * 900000);

  const newUser: User = {
    id: newUserId,
    fullName: fullName.trim(),
    mobile: cleanMobile,
    passwordHash: hashPassword(password),
    role: 'user',
    referralCode: userRefCode,
    referredBy: referredByUserId,
    balance: 0,
    totalVerifiedRewards: 0,
    activePlanId: null,
    planActivationDate: null,
    planExpiryDate: null,
    createdAt: new Date().toISOString(),
  };

  db.users.push(newUser);

  const token = generateToken();
  db.sessions.push({
    token,
    userId: newUserId,
    createdAt: new Date().toISOString(),
  });

  saveDB(db);

  const { passwordHash, ...safeUser } = newUser;
  res.json({
    token,
    user: safeUser,
    message: 'Account created successfully! Welcome to ProfitNest.',
  });
});

// Auth: Login
app.post('/api/auth/login', (req, res) => {
  const { mobile, password } = req.body;
  if (!mobile || !password) {
    return res.status(400).json({ error: 'Please provide both mobile number and password.' });
  }
  const cleanMobile = mobile.replace(/[^0-9]/g, '');
  const db = loadDB();
  const user = db.users.find((u) => u.mobile === cleanMobile);
  if (!user || user.passwordHash !== hashPassword(password)) {
    return res.status(401).json({ error: 'Invalid mobile number or password.' });
  }

  const token = generateToken();
  db.sessions.push({
    token,
    userId: user.id,
    createdAt: new Date().toISOString(),
  });

  saveDB(db);

  const { passwordHash, ...safeUser } = user;
  res.json({
    token,
    user: safeUser,
    message: `Welcome back, ${user.fullName}!`,
  });
});

// Auth: Get Current Profile
app.get('/api/auth/me', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const db = loadDB();
  const plan = user.activePlanId ? db.plans.find((p) => p.id === user.activePlanId) : null;
  const { passwordHash, ...safeUser } = user;
  res.json({ user: safeUser, plan });
});

// Auth: Change Password
app.post('/api/auth/change-password', authenticate, (req, res) => {
  const { oldPassword, newPassword, confirmNewPassword } = req.body;
  const user = (req as any).user as User;
  if (!oldPassword || !newPassword) {
    return res.status(400).json({ error: 'All fields are required.' });
  }
  if (user.passwordHash !== hashPassword(oldPassword)) {
    return res.status(400).json({ error: 'Current password is incorrect.' });
  }
  if (newPassword !== confirmNewPassword) {
    return res.status(400).json({ error: 'New passwords do not match.' });
  }
  if (newPassword.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters.' });
  }

  const db = loadDB();
  const dbUser = db.users.find((u) => u.id === user.id);
  if (dbUser) {
    dbUser.passwordHash = hashPassword(newPassword);
    saveDB(db);
  }
  res.json({ success: true, message: 'Password changed successfully.' });
});

// Auth: Forgot Password Information
app.post('/api/auth/forgot-password', (req, res) => {
  const { mobile } = req.body;
  const db = loadDB();
  res.json({
    message: `For account recovery and security verification for ${mobile || 'your account'}, please contact Administrator Shabahat Ali Kazmi via WhatsApp/Call at ${db.settings.adminContact} with your registered Mobile Number.`,
    adminContact: db.settings.adminContact,
    ownerContact: db.settings.ownerContact,
  });
});

// Dashboard stats
app.get('/api/dashboard', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const db = loadDB();
  const today = getTodayDateStr();

  const userCompletionsToday = db.videoCompletions.filter(
    (c) => c.userId === user.id && c.dateStr === today
  );

  const activePlan = user.activePlanId ? db.plans.find((p) => p.id === user.activePlanId) : null;

  let remainingDays = 0;
  let isPlanActive = false;
  if (user.activePlanId && user.planExpiryDate) {
    const diff = new Date(user.planExpiryDate).getTime() - Date.now();
    if (diff > 0) {
      remainingDays = Math.ceil(diff / (1000 * 60 * 60 * 24));
      isPlanActive = true;
    }
  }

  const recentTransactions = db.transactions
    .filter((t) => t.userId === user.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const { passwordHash, ...safeUser } = user;
  res.json({
    user: safeUser,
    activePlan,
    isPlanActive,
    remainingDays,
    completedToday: userCompletionsToday.length,
    maxDailyVideos: activePlan ? activePlan.dailyVideos : 2,
    recentTransactions,
  });
});

// Plans list
app.get('/api/plans', (req, res) => {
  const db = loadDB();
  res.json({ plans: db.plans });
});

// Videos for today
app.get('/api/videos', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const db = loadDB();
  const today = getTodayDateStr();

  const activePlan = user.activePlanId ? db.plans.find((p) => p.id === user.activePlanId) : null;
  const completedToday = db.videoCompletions.filter(
    (c) => c.userId === user.id && c.dateStr === today
  );

  const completedVideoIds = completedToday.map((c) => c.videoId);

  const rewardPerVideo = activePlan ? activePlan.rewardPerVideo : 0;

  const videosWithStatus = db.videos.map((vid) => {
    const isCompleted = completedVideoIds.includes(vid.id);
    return {
      ...vid,
      rewardAmount: rewardPerVideo,
      isCompleted,
      canWatch: Boolean(activePlan && !isCompleted && completedToday.length < 2),
    };
  });

  res.json({
    videos: videosWithStatus,
    activePlan: activePlan
      ? {
          name: activePlan.name,
          price: activePlan.price,
          rewardPerVideo: activePlan.rewardPerVideo,
        }
      : null,
    completedTodayCount: completedToday.length,
    maxDailyVideos: 2,
    requiresPlan: !activePlan,
  });
});

// Claim video reward with backend verification
app.post('/api/videos/claim', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const { videoId, watchDurationSeconds } = req.body;

  if (!videoId) {
    return res.status(400).json({ error: 'Video ID is required.' });
  }

  const db = loadDB();
  const activePlan = user.activePlanId ? db.plans.find((p) => p.id === user.activePlanId) : null;
  if (!activePlan) {
    return res.status(400).json({
      error: 'You need an active 30-day verified plan to earn video rewards. Please select and activate a plan.',
    });
  }

  const today = getTodayDateStr();
  const existingCompletionsToday = db.videoCompletions.filter(
    (c) => c.userId === user.id && c.dateStr === today
  );

  if (existingCompletionsToday.length >= 2) {
    return res.status(400).json({
      error: 'Daily limit reached. You have completed the maximum 2 eligible video tasks for today.',
    });
  }

  if (existingCompletionsToday.some((c) => c.videoId === videoId)) {
    return res.status(400).json({
      error: 'You have already claimed the reward for this video task today.',
    });
  }

  // Ensure genuine watch duration
  const targetVideo = db.videos.find((v) => v.id === videoId);
  if (!targetVideo) {
    return res.status(404).json({ error: 'Video task not found.' });
  }

  if (typeof watchDurationSeconds !== 'number' || watchDurationSeconds < targetVideo.durationSeconds - 2) {
    return res.status(400).json({
      error: `Verification failed. You must watch the video for its full duration (${targetVideo.durationSeconds}s) to verify task completion.`,
    });
  }

  const rewardAmount = activePlan.rewardPerVideo;

  // Add completion record
  const completionId = 'comp-' + crypto.randomBytes(6).toString('hex');
  db.videoCompletions.push({
    id: completionId,
    userId: user.id,
    videoId: targetVideo.id,
    rewardAmount,
    completedAt: new Date().toISOString(),
    dateStr: today,
  });

  // Credit user balance
  const dbUser = db.users.find((u) => u.id === user.id);
  if (dbUser) {
    dbUser.balance += rewardAmount;
    dbUser.totalVerifiedRewards += rewardAmount;
  }

  // Add transaction
  const trxId = 'TRX-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  db.transactions.push({
    id: trxId,
    userId: user.id,
    type: 'Video Reward',
    amount: rewardAmount,
    status: 'Completed',
    description: `Verified Reward for Task: ${targetVideo.title} (${activePlan.name})`,
    createdAt: new Date().toISOString(),
  });

  saveDB(db);

  res.json({
    success: true,
    rewardAmount,
    newBalance: dbUser?.balance,
    message: `Verified reward of Rs. ${rewardAmount} has been credited to your account!`,
  });
});

// Deposits: Get and Create
app.get('/api/deposits', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const db = loadDB();
  const userDeposits = db.deposits
    .filter((d) => d.userId === user.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ deposits: userDeposits });
});

app.post('/api/deposits', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const { planId, paymentMethod, senderNumber, transactionId, notes } = req.body;

  if (!planId || !paymentMethod || !senderNumber || !transactionId) {
    return res.status(400).json({ error: 'Plan, payment method, sender mobile/account, and Transaction ID (TID) are required.' });
  }

  const db = loadDB();
  const selectedPlan = db.plans.find((p) => p.id === parseInt(planId));
  if (!selectedPlan) {
    return res.status(400).json({ error: 'Invalid plan selected.' });
  }

  // Check if transaction ID was already submitted
  if (db.deposits.some((d) => d.transactionId.trim().toUpperCase() === transactionId.trim().toUpperCase())) {
    return res.status(400).json({ error: 'This Transaction ID has already been submitted. Please check your TID.' });
  }

  const depositId = 'DEP-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const newDeposit = {
    id: depositId,
    userId: user.id,
    planId: selectedPlan.id,
    amount: selectedPlan.price,
    paymentMethod,
    senderNumber: senderNumber.trim(),
    transactionId: transactionId.trim().toUpperCase(),
    notes: notes ? notes.trim() : '',
    status: 'Pending' as const,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.deposits.push(newDeposit);

  // Record pending transaction entry
  db.transactions.push({
    id: newDeposit.id,
    userId: user.id,
    type: 'Deposit',
    amount: selectedPlan.price,
    status: 'Pending',
    description: `Deposit for ${selectedPlan.name} (TID: ${newDeposit.transactionId})`,
    createdAt: new Date().toISOString(),
  });

  saveDB(db);

  res.json({
    success: true,
    deposit: newDeposit,
    message: 'Deposit request submitted successfully. It will be verified by Administrator Shabahat Ali Kazmi shortly.',
  });
});

// Withdrawals: Get and Create
app.get('/api/withdrawals', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const db = loadDB();
  const userWithdrawals = db.withdrawals
    .filter((w) => w.userId === user.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ withdrawals: userWithdrawals, availableBalance: user.balance });
});

app.post('/api/withdrawals', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const { amount, accountHolder, paymentMethod, accountNumber } = req.body;

  const numAmount = parseFloat(amount);
  if (!numAmount || numAmount <= 0) {
    return res.status(400).json({ error: 'Please enter a valid withdrawal amount.' });
  }
  if (!accountHolder || !paymentMethod || !accountNumber) {
    return res.status(400).json({ error: 'Account holder name, payment method, and account number are required.' });
  }

  const db = loadDB();
  const dbUser = db.users.find((u) => u.id === user.id);
  if (!dbUser || dbUser.balance < numAmount) {
    return res.status(400).json({
      error: `Insufficient available balance. Your verified withdrawable balance is Rs. ${dbUser?.balance || 0}.`,
    });
  }

  // Minimum withdrawal threshold
  if (numAmount < 100) {
    return res.status(400).json({ error: 'Minimum withdrawal amount is Rs. 100.' });
  }

  // Deduct from user balance immediately to prevent double spending
  dbUser.balance -= numAmount;

  const withdrawalId = 'WTH-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const newWithdrawal = {
    id: withdrawalId,
    userId: user.id,
    amount: numAmount,
    accountHolder: accountHolder.trim(),
    paymentMethod,
    accountNumber: accountNumber.trim(),
    status: 'Pending' as const,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.withdrawals.push(newWithdrawal);

  db.transactions.push({
    id: newWithdrawal.id,
    userId: user.id,
    type: 'Withdrawal',
    amount: numAmount,
    status: 'Pending',
    description: `Withdrawal request to ${paymentMethod} (${accountNumber})`,
    createdAt: new Date().toISOString(),
  });

  saveDB(db);

  res.json({
    success: true,
    withdrawal: newWithdrawal,
    remainingBalance: dbUser.balance,
    message: 'Withdrawal request submitted! Administrator will process payout to your account.',
  });
});

// Transactions: All for current user
app.get('/api/transactions', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const db = loadDB();
  const userTransactions = db.transactions
    .filter((t) => t.userId === user.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ transactions: userTransactions });
});

// Referrals
app.get('/api/referrals', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const db = loadDB();

  const referredUsers = db.users
    .filter((u) => u.referredBy === user.id)
    .map((u) => ({
      fullName: u.fullName,
      mobile: u.mobile.slice(0, 4) + '***' + u.mobile.slice(-3),
      createdAt: u.createdAt,
      activePlan: u.activePlanId ? `Plan ${u.activePlanId}` : 'No Active Plan',
    }));

  const referralTransactions = db.transactions.filter(
    (t) => t.userId === user.id && t.type === 'Referral Reward'
  );
  const totalReferralRewards = referralTransactions.reduce((acc, t) => acc + t.amount, 0);

  res.json({
    referralCode: user.referralCode,
    totalInvited: referredUsers.length,
    referredUsers,
    totalReferralRewards,
    commissionRate: db.settings.referralCommissionRate,
  });
});

// Real Leaderboard (only genuine verified rewards)
app.get('/api/leaderboard', (req, res) => {
  const db = loadDB();
  const leaders = db.users
    .filter((u) => u.role !== 'admin' && u.totalVerifiedRewards > 0)
    .map((u) => ({
      name: u.fullName,
      maskedMobile: u.mobile.slice(0, 4) + '****' + u.mobile.slice(-2),
      totalRewards: u.totalVerifiedRewards,
      plan: u.activePlanId ? `Plan ${u.activePlanId}` : 'Member',
    }))
    .sort((a, b) => b.totalRewards - a.totalRewards)
    .slice(0, 10);

  res.json({ leaderboard: leaders });
});

// Support tickets: Get and Submit
app.get('/api/support', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const db = loadDB();
  const tickets = db.supportTickets
    .filter((t) => t.userId === user.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ tickets });
});

app.post('/api/support', authenticate, (req, res) => {
  const user = (req as any).user as User;
  const { subject, category, message } = req.body;

  if (!subject || !message) {
    return res.status(400).json({ error: 'Subject and message are required.' });
  }

  const db = loadDB();
  const ticketId = 'TKT-' + crypto.randomBytes(3).toString('hex').toUpperCase();

  const newTicket = {
    id: ticketId,
    userId: user.id,
    userName: user.fullName,
    mobile: user.mobile,
    subject: subject.trim(),
    category: category || 'General Question',
    message: message.trim(),
    status: 'Open' as const,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.supportTickets.push(newTicket);
  saveDB(db);

  res.json({
    success: true,
    ticket: newTicket,
    message: 'Support request received. Admin Shabahat Ali Kazmi will review it promptly.',
  });
});

// ======================== ADMIN ENDPOINTS ========================

// Admin Overview
app.get('/api/admin/overview', authenticate, requireAdmin, (req, res) => {
  const db = loadDB();
  const totalUsers = db.users.filter((u) => u.role !== 'admin').length;
  const activePlansCount = db.users.filter((u) => u.activePlanId !== null).length;
  const pendingDeposits = db.deposits.filter((d) => d.status === 'Pending').length;
  const pendingWithdrawals = db.withdrawals.filter((w) => w.status === 'Pending').length;
  const totalPaidOut = db.withdrawals
    .filter((w) => w.status === 'Paid')
    .reduce((sum, w) => sum + w.amount, 0);
  const totalDeposited = db.deposits
    .filter((d) => d.status === 'Approved')
    .reduce((sum, d) => sum + d.amount, 0);

  res.json({
    totalUsers,
    activePlansCount,
    pendingDeposits,
    pendingWithdrawals,
    totalPaidOut,
    totalDeposited,
  });
});

// Admin Users list
app.get('/api/admin/users', authenticate, requireAdmin, (req, res) => {
  const db = loadDB();
  const safeUsers = db.users.map(({ passwordHash, ...u }) => u);
  res.json({ users: safeUsers });
});

// Admin Deposits list
app.get('/api/admin/deposits', authenticate, requireAdmin, (req, res) => {
  const db = loadDB();
  const enriched = db.deposits.map((d) => {
    const user = db.users.find((u) => u.id === d.userId);
    const plan = db.plans.find((p) => p.id === d.planId);
    return {
      ...d,
      userName: user ? user.fullName : 'Unknown',
      userMobile: user ? user.mobile : 'Unknown',
      planName: plan ? plan.name : `Plan ${d.planId}`,
    };
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ deposits: enriched });
});

// Admin Verify Deposit (Approve or Reject)
app.post('/api/admin/deposits/:id/verify', authenticate, requireAdmin, (req, res) => {
  const adminUser = (req as any).user as User;
  const { id } = req.params;
  const { action, adminNote } = req.body; // 'approve' | 'reject'

  if (action !== 'approve' && action !== 'reject') {
    return res.status(400).json({ error: 'Action must be approve or reject.' });
  }

  const db = loadDB();
  const deposit = db.deposits.find((d) => d.id === id);
  if (!deposit) {
    return res.status(404).json({ error: 'Deposit request not found.' });
  }
  if (deposit.status !== 'Pending') {
    return res.status(400).json({ error: `Deposit is already marked as ${deposit.status}.` });
  }

  const user = db.users.find((u) => u.id === deposit.userId);
  if (!user) {
    return res.status(404).json({ error: 'User for this deposit not found.' });
  }

  const now = new Date();
  if (action === 'approve') {
    deposit.status = 'Approved';
    deposit.adminNote = adminNote || 'Payment verified by Shabahat Ali Kazmi';
    deposit.updatedAt = now.toISOString();

    // Activate the 30-day plan!
    user.activePlanId = deposit.planId;
    user.planActivationDate = now.toISOString();
    const expiry = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    user.planExpiryDate = expiry.toISOString();

    // Update corresponding transaction status
    const trx = db.transactions.find((t) => t.id === deposit.id);
    if (trx) {
      trx.status = 'Approved';
    }

    // Process referral commission if user was referred
    if (user.referredBy) {
      const referrer = db.users.find((u) => u.id === user.referredBy);
      if (referrer) {
        const commission = Math.round((deposit.amount * db.settings.referralCommissionRate) / 100);
        if (commission > 0) {
          referrer.balance += commission;
          referrer.totalVerifiedRewards += commission;

          const refTrxId = 'REF-' + crypto.randomBytes(4).toString('hex').toUpperCase();
          db.transactions.push({
            id: refTrxId,
            userId: referrer.id,
            type: 'Referral Reward',
            amount: commission,
            status: 'Completed',
            description: `${db.settings.referralCommissionRate}% Referral bonus from ${user.fullName}'s verified plan activation`,
            createdAt: now.toISOString(),
          });
        }
      }
    }

    // Log admin action
    db.adminLogs.push({
      id: 'log-' + crypto.randomBytes(4).toString('hex'),
      action: 'DEPOSIT_APPROVED',
      details: `Approved Rs. ${deposit.amount} for User ${user.fullName} (${user.mobile}). Activated Plan ${deposit.planId} for 30 days.`,
      adminMobile: adminUser.mobile,
      createdAt: now.toISOString(),
    });
  } else {
    deposit.status = 'Rejected';
    deposit.adminNote = adminNote || 'Transaction verification failed.';
    deposit.updatedAt = now.toISOString();

    const trx = db.transactions.find((t) => t.id === deposit.id);
    if (trx) {
      trx.status = 'Rejected';
    }

    db.adminLogs.push({
      id: 'log-' + crypto.randomBytes(4).toString('hex'),
      action: 'DEPOSIT_REJECTED',
      details: `Rejected Deposit ${deposit.id} (Rs. ${deposit.amount}) for User ${user.fullName}. Reason: ${adminNote || 'None provided'}`,
      adminMobile: adminUser.mobile,
      createdAt: now.toISOString(),
    });
  }

  saveDB(db);
  res.json({ success: true, deposit, message: `Deposit marked as ${deposit.status}.` });
});

// Admin Withdrawals list
app.get('/api/admin/withdrawals', authenticate, requireAdmin, (req, res) => {
  const db = loadDB();
  const enriched = db.withdrawals.map((w) => {
    const user = db.users.find((u) => u.id === w.userId);
    return {
      ...w,
      userName: user ? user.fullName : 'Unknown',
      userMobile: user ? user.mobile : 'Unknown',
    };
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ withdrawals: enriched });
});

// Admin Update Withdrawal (Processing, Paid, Rejected)
app.post('/api/admin/withdrawals/:id/update', authenticate, requireAdmin, (req, res) => {
  const adminUser = (req as any).user as User;
  const { id } = req.params;
  const { status, adminReference } = req.body;

  if (!['Processing', 'Paid', 'Rejected'].includes(status)) {
    return res.status(400).json({ error: 'Status must be Processing, Paid, or Rejected.' });
  }

  const db = loadDB();
  const withdrawal = db.withdrawals.find((w) => w.id === id);
  if (!withdrawal) {
    return res.status(404).json({ error: 'Withdrawal not found.' });
  }

  const user = db.users.find((u) => u.id === withdrawal.userId);
  const now = new Date().toISOString();

  // If rejected, refund user's balance
  if (status === 'Rejected' && withdrawal.status !== 'Rejected') {
    if (user) {
      user.balance += withdrawal.amount;
    }
  }

  withdrawal.status = status;
  withdrawal.adminReference = adminReference || `Processed by Shabahat Ali Kazmi`;
  withdrawal.updatedAt = now;

  const trx = db.transactions.find((t) => t.id === withdrawal.id);
  if (trx) {
    trx.status = status;
  }

  db.adminLogs.push({
    id: 'log-' + crypto.randomBytes(4).toString('hex'),
    action: `WITHDRAWAL_${status.toUpperCase()}`,
    details: `Withdrawal ${withdrawal.id} of Rs. ${withdrawal.amount} updated to ${status}. Ref: ${adminReference || 'N/A'}`,
    adminMobile: adminUser.mobile,
    createdAt: now,
  });

  saveDB(db);
  res.json({ success: true, withdrawal, message: `Withdrawal updated to ${status}.` });
});

// Admin Support Tickets
app.get('/api/admin/support', authenticate, requireAdmin, (req, res) => {
  const db = loadDB();
  res.json({
    tickets: db.supportTickets.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ),
  });
});

app.post('/api/admin/support/:id/reply', authenticate, requireAdmin, (req, res) => {
  const { id } = req.params;
  const { adminReply, status } = req.body;
  const db = loadDB();
  const ticket = db.supportTickets.find((t) => t.id === id);
  if (!ticket) {
    return res.status(404).json({ error: 'Ticket not found.' });
  }
  ticket.adminReply = adminReply;
  if (status) ticket.status = status;
  ticket.updatedAt = new Date().toISOString();
  saveDB(db);
  res.json({ success: true, ticket });
});

// Admin Announcements
app.post('/api/admin/announcements', authenticate, requireAdmin, (req, res) => {
  const { title, message } = req.body;
  if (!title || !message) {
    return res.status(400).json({ error: 'Title and message required.' });
  }
  const db = loadDB();
  const annId = 'ann-' + crypto.randomBytes(3).toString('hex');
  const newAnn = {
    id: annId,
    title: title.trim(),
    message: message.trim(),
    active: true,
    createdAt: new Date().toISOString(),
  };
  db.announcements.unshift(newAnn);
  saveDB(db);
  res.json({ success: true, announcement: newAnn });
});

// Admin Update Settings (Contacts, Payment details)
app.post('/api/admin/settings', authenticate, requireAdmin, (req, res) => {
  const adminUser = (req as any).user as User;
  const { ownerName, ownerContact, adminName, adminContact, referralCommissionRate, paymentMethods } = req.body;
  const db = loadDB();

  if (ownerName) db.settings.ownerName = ownerName.trim();
  if (ownerContact) db.settings.ownerContact = ownerContact.trim();
  if (adminName) db.settings.adminName = adminName.trim();
  if (adminContact) db.settings.adminContact = adminContact.trim();
  if (typeof referralCommissionRate === 'number') db.settings.referralCommissionRate = referralCommissionRate;
  if (Array.isArray(paymentMethods)) db.settings.paymentMethods = paymentMethods;

  db.adminLogs.push({
    id: 'log-' + crypto.randomBytes(4).toString('hex'),
    action: 'SETTINGS_UPDATED',
    details: 'Administrator updated platform contacts and payment configurations',
    adminMobile: adminUser.mobile,
    createdAt: new Date().toISOString(),
  });

  saveDB(db);
  res.json({ success: true, settings: db.settings });
});

// Admin Audit Logs
app.get('/api/admin/logs', authenticate, requireAdmin, (req, res) => {
  const db = loadDB();
  res.json({
    logs: db.adminLogs.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ),
  });
});

// ======================== FRONTEND VITE INTEGRATION ========================
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ProfitNest backend & frontend server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
  process.exit(1);
});
